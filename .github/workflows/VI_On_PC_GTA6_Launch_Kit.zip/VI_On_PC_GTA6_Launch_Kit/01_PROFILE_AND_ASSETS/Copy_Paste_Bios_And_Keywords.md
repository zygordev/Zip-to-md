# Copy-Paste Profile Pack (`@vi.onpc` / `VI On PC`)

## 1. Brand Identity Across All 3 Platforms
- **Display Name:** `VI On PC`
- **Handle / Username:** `@vi.onpc` *(Backups if taken: `@vi.onpc_` or `@vi.onpc.hq`)*
- **Profile Picture:** Use `VI_On_PC_Profile_Avatar.jpg` in this folder.

---

## 2. YouTube Channel Setup
- **Audience Setting:** `No, I almost never upload content that's made for kids`
- **Country of Residence:** `United States`
- **Channel Keywords (Paste in YouTube Studio -> Settings -> Channel -> Basic Info):**
```text
GTA 6, GTA VI, GTA 6 PS5, GTA 6 setup, GTA 6 laptop setup, play GTA 6 on laptop, PS5 to PC, 60fps laptop setup, DualSense on PC, GTA 6 pre-load, Vice City setup, PS5 desk setup, GTA 6 launch week, gaming laptop setup, Leonida
```
- **YouTube Channel Description:**
```text
Everyone said wait until 2028 to play GTA 6 on a laptop… I took that personally 💀💻

Turning my regular laptop into a locked 60FPS Vice City setup for launch week. No $3,000 gaming PC, no jet-engine fans, zero input lag.

Full laptop method + launch week perks 👇
(Link below)

gta 6, gta vi, gta 6 on laptop, play gta 6 on pc, vice city 60fps, gta 6 desk setup, dualsense laptop, leonida, gta 6 preload, gaming laptop setup
```

---

## 3. TikTok Profile Setup
- **Account Type:** Business Account -> Category: `Gaming` (Unlocks clickable bio link immediately)
- **TikTok Bio:**
```text
they said wait till 2028 💀💻
GTA 6 on my laptop at 60fps
exact method + perks 👇
```

---

## 4. Instagram Profile Setup
- **Account Type:** Professional Account -> `Creator` -> Category: `Gamer`
- **Instagram Bio:**
```text
my laptop wasn't supposed to run GTA 6 at 60fps yet here we are 💻🔥
zero lag • no $3k rig needed
comment "SETUP" or tap below for the method 👇
```
