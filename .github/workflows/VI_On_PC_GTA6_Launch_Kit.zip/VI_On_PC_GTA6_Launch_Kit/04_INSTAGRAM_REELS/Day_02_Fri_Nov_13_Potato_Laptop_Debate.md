# Day 2 (Fri, Nov 13) — The 'Potato Laptop' Debate & Settings Bait — Instagram Reels Pack (`@vi.onpc`)
**Daily Goal:** Spark massive comment debates ('How is a basic laptop running this at 60fps?!') to skyrocket watch time and drive bio clicks.
**ManyChat Trigger:** Make sure your ManyChat automation triggers on the keyword `SETUP` and replies with your landing page link.

## Reel #1: Task Manager 5% CPU Flex (Slot 1 — 18:00 Morocco (12:00 PM EST))
- **What to Film (8–12s on iPhone 60FPS):** Show Windows Task Manager open on the left side of your laptop screen (showing tiny CPU/GPU usage) while a fast 60FPS PS5 game runs in the window on the right.
- **Native Reels Text Hook (Top Center):** `Running 60FPS on a regular laptop while CPU sits at 5% 💀💻`
- **Bottom Small Text:** `Your PS5 does 100% of the work • Setup in bio`
- **Location Tag:** `Miami, Florida` or `Los Angeles, California` (for US feed routing)
- **Instagram Reel Caption + Hashtags (Copy-Paste):**
  ```text
Laptop fans aren't even spinning 💀💻 Because your PS5 does 100% of the rendering!

Comment "SETUP" and I'll DM you the exact 60FPS laptop config + launch perks.

#gta6 #gtavi #gaminglaptop #gamingsetup
  ```
- **Poco F7 First-Comment Trigger (Post from 2nd phone):**
  `"Bro had me thinking his office laptop had an RTX 5090 in it 😭 smart method though"`

## Reel #2: The 2 Hidden 60FPS Settings (Slot 2 — 21:00 Morocco (3:00 PM EST))
- **What to Film (8–12s on iPhone 60FPS):** Zoom in on the Sony PS Remote Play PC settings menu: click Resolution -> 1080p, and Frame Rate -> High. Then pan to smooth gameplay.
- **Native Reels Text Hook (Top Center):** `Stop playing on your laptop with blurry graphics. Change these 2 settings 👇`
- **Bottom Small Text:** `Save this before GTA 6 drops on Nov 19`
- **Location Tag:** `Miami, Florida` or `Los Angeles, California` (for US feed routing)
- **Instagram Reel Caption + Hashtags (Copy-Paste):**
  ```text
Save this before Nov 19 ⚡ Don't play on default 30fps settings!

Comment "SETUP" and I'll DM you the full zero-lag checklist + launch week PSN perks.

#gta6 #gtavi #ps5tips #gamingsetup
  ```
- **Poco F7 First-Comment Trigger (Post from 2nd phone):**
  `"Thank you!! Mine was stuck on Standard frame rate this whole time"`

## Reel #3: Video Reply to Top Day-1 Comment (Slot 3 — 00:00 Morocco (6:00 PM EST))
- **What to Film (8–12s on iPhone 60FPS):** Use the native Video Reply feature to reply to the top question from Day 1 while showing your PS5 Ethernet cable + laptop USB-C DualSense setup.
- **Native Reels Text Hook (Top Center):** `Replying to @comment: Yes, any Windows 10/11 or Mac laptop works 💻✅`
- **Bottom Small Text:** `Requires your own PS5 + game • Link in bio`
- **Location Tag:** `Miami, Florida` or `Los Angeles, California` (for US feed routing)
- **Instagram Reel Caption + Hashtags (Copy-Paste):**
  ```text
Answering the #1 question from yesterday's Reel 💻🔥 Comment "SETUP" and I'll DM you the exact checklist + PSN perks!

#gta6 #gtavi #gaminglaptop #ps5
  ```
- **Poco F7 First-Comment Trigger (Post from 2nd phone):**
  `"Just tested this on my school laptop and it actually runs smooth af"`

## Reel #4: Dark Room Vice City Neon POV (Slot 4 — 03:00 Morocco (9:00 PM EST - Auto-Scheduled))
- **What to Film (8–12s on iPhone 60FPS):** POV filming over your shoulder in a dark room as you play at 60FPS on the laptop screen with pink/cyan lighting.
- **Native Reels Text Hook (Top Center):** `6 days left until Vice City takes over this laptop desk 🌴💻`
- **Bottom Small Text:** `Setup guide + PSN perks in bio`
- **Location Tag:** `Miami, Florida` or `Los Angeles, California` (for US feed routing)
- **Instagram Reel Caption + Hashtags (Copy-Paste):**
  ```text
6 days left until Vice City 🌴💻 Comment "SETUP" to get your laptop dialed in before launch night!

#gta6 #gtavi #vicecity #gamingsetup
  ```
- **Poco F7 First-Comment Trigger (Post from 2nd phone):**
  `"This desk vibe is elite, Nov 19 cannot come fast enough"`
