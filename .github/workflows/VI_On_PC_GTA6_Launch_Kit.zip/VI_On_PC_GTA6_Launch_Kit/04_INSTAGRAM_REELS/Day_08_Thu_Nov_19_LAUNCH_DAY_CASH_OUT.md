# Day 8 (Thu, Nov 19) — OFFICIAL GTA 6 LAUNCH DAY CASHOUT — Instagram Reels Pack (`@vi.onpc`)
**Daily Goal:** Switch your landing page to LIVE NOW mode! Show real GTA 6 Vice City gameplay running on your laptop screen with your DualSense in frame.
**ManyChat Trigger:** Make sure your ManyChat automation triggers on the keyword `SETUP` and replies with your landing page link.

## Reel #1: ACTUAL GTA 6 Running on My Laptop Flex (Mega Viral Clip) (Slot 1 — 18:00 Morocco (12:00 PM EST))
- **What to Film (8–12s on iPhone 60FPS):** Show actual GTA 6 gameplay in Vice City running smoothly at 60FPS on your laptop screen, then pan out to show your DualSense controller and laptop keyboard.
- **Native Reels Text Hook (Top Center):** `Playing my PS5 copy of GTA 6 on my laptop at 60FPS on Day 1 💀🌴`
- **Bottom Small Text:** `Exact 0-lag method + PSN perks in bio 👇`
- **Location Tag:** `Miami, Florida` or `Los Angeles, California` (for US feed routing)
- **Instagram Reel Caption + Hashtags (Copy-Paste):**
  ```text
Day 1 on the laptop goes crazy 💀🌴

Comment "SETUP" and I'll DM you the exact 60FPS PS5-to-laptop method + launch week PSN perks!

(Requires your own PS5 + official game)

#gta6 #gtavi #vicecity #gaminglaptop #ps5
  ```
- **Poco F7 First-Comment Trigger (Post from 2nd phone):**
  `"WAIT HOW IS IT SO SMOOTH ON A LAPTOP?! SETUP"`

## Reel #2: Vice City Driving Latency Test on Laptop (Slot 2 — 21:00 Morocco (3:00 PM EST))
- **What to Film (8–12s on iPhone 60FPS):** Drive a fast car down Ocean Beach / Vice City neon streets on your laptop screen while keeping your hands + DualSense thumbsticks in the bottom half of the vertical frame.
- **Native Reels Text Hook (Top Center):** `Look at the graphics & 0ms response on my laptop screen 🔥🚗`
- **Bottom Small Text:** `Full PS5-to-laptop setup in bio`
- **Location Tag:** `Miami, Florida` or `Los Angeles, California` (for US feed routing)
- **Instagram Reel Caption + Hashtags (Copy-Paste):**
  ```text
Zero input delay driving through Vice City on a regular laptop 🔥🚗

Comment "SETUP" and I'll DM you the exact 60FPS method + perks!

#gta6 #gtavi #vicecity #ps5
  ```
- **Poco F7 First-Comment Trigger (Post from 2nd phone):**
  `"SETUP"`

## Reel #3: Playing GTA 6 in Bed on Laptop POV (Slot 3 — 00:00 Morocco (6:00 PM EST))
- **What to Film (8–12s on iPhone 60FPS):** Film from bed with your laptop on your lap running GTA 6 via PS Remote Play while holding the DualSense.
- **Native Reels Text Hook (Top Center):** `Playing GTA 6 from bed on my laptop while the TV is taken 💀🛌`
- **Bottom Small Text:** `Comment SETUP for the 60FPS method 👇`
- **Location Tag:** `Miami, Florida` or `Los Angeles, California` (for US feed routing)
- **Instagram Reel Caption + Hashtags (Copy-Paste):**
  ```text
Peak comfort for launch week 💀🛌 Comment "SETUP" and I'll DM you how to stream your PS5 copy of GTA 6 to your laptop in 60FPS!

#gta6 #gtavi #ps5 #gaminglaptop
  ```
- **Poco F7 First-Comment Trigger (Post from 2nd phone):**
  `"Doing this tonight 100% SETUP"`

## Reel #4: Launch Night Live Stream + Perks Recap (Slot 4 — 03:00 Morocco (9:00 PM EST - Auto-Scheduled))
- **What to Film (8–12s on iPhone 60FPS):** Show your laptop running GTA 6 + OBS Studio streaming live on your second window.
- **Native Reels Text Hook (Top Center):** `We are LIVE playing GTA 6 on the laptop setup all night 🔴🌴`
- **Bottom Small Text:** `Stream link + 60FPS setup + PSN perks in bio 👇`
- **Location Tag:** `Miami, Florida` or `Los Angeles, California` (for US feed routing)
- **Instagram Reel Caption + Hashtags (Copy-Paste):**
  ```text
Pull up to the launch night stream 🔴🌴 Comment "SETUP" for the stream link + my 60FPS laptop method & PSN perks!

#gta6 #gtavi #ps5 #streamer
  ```
- **Poco F7 First-Comment Trigger (Post from 2nd phone):**
  `"SETUP"`
