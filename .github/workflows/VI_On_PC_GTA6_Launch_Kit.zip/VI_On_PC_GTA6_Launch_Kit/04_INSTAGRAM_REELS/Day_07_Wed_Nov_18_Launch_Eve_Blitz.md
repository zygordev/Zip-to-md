# Day 7 (Wed, Nov 18) — Launch Eve (< 24 Hours Left) Hype Blitz — Instagram Reels Pack (`@vi.onpc`)
**Daily Goal:** Maximum search volume day. Millions of people search GTA 6 every hour today. Push both your 60FPS setup AND your spoiler-delayed live stream.
**ManyChat Trigger:** Make sure your ManyChat automation triggers on the keyword `SETUP` and replies with your landing page link.

## Reel #1: 24 Hours Left Countdown Flex (Slot 1 — 18:00 Morocco (12:00 PM EST))
- **What to Film (8–12s on iPhone 60FPS):** Close-up of the final `< 24 Hours` timer ticking down on your laptop screen with your DualSense in hand.
- **Native Reels Text Hook (Top Center):** `LESS THAN 24 HOURS. Playing GTA 6 on this laptop all weekend 💻🔥`
- **Bottom Small Text:** `Own PS5 + game required • Setup + stream in bio`
- **Location Tag:** `Miami, Florida` or `Los Angeles, California` (for US feed routing)
- **Instagram Reel Caption + Hashtags (Copy-Paste):**
  ```text
LESS THAN 24 HOURS LEFT 💻🔥 Comment "SETUP" right now and I'll DM you the 60FPS laptop guide + launch night perks before midnight!

#gta6 #gtavi #ps5 #gamingsetup
  ```
- **Poco F7 First-Comment Trigger (Post from 2nd phone):**
  `"SETUP"`

## Reel #2: OBS 120-Second Anti-Spoiler Delay Setup (Slot 2 — 21:00 Morocco (3:00 PM EST))
- **What to Film (8–12s on iPhone 60FPS):** Show OBS Studio -> Settings -> Advanced -> Stream Delay enabled at `120s` next to your laptop capture window.
- **Native Reels Text Hook (Top Center):** `Streaming GTA 6 from my laptop tonight with a 2-minute anti-spoiler delay 🛡️🎥`
- **Bottom Small Text:** `Stream link + laptop setup in bio 👇`
- **Location Tag:** `Miami, Florida` or `Los Angeles, California` (for US feed routing)
- **Instagram Reel Caption + Hashtags (Copy-Paste):**
  ```text
Nobody is spoiling the story in chat tonight 🛡️💻 Comment "SETUP" for the stream link + my 60FPS laptop setup!

#gta6 #gtavi #ps5 #streamer
  ```
- **Poco F7 First-Comment Trigger (Post from 2nd phone):**
  `"W streamer for adding a spoiler delay"`

## Reel #3: Final 6 Hours Desk Lock-In (Slot 3 — 00:00 Morocco (6:00 PM EST))
- **What to Film (8–12s on iPhone 60FPS):** Fast montage plugging in Ethernet, plugging in USB-C DualSense, putting on headset, and opening the countdown screen on the laptop.
- **Native Reels Text Hook (Top Center):** `Final 6 hours. Locking in the 60FPS laptop station for midnight 🔓💻`
- **Bottom Small Text:** `Full setup + launch perks in bio`
- **Location Tag:** `Miami, Florida` or `Los Angeles, California` (for US feed routing)
- **Instagram Reel Caption + Hashtags (Copy-Paste):**
  ```text
Locking in for midnight 🔓💻 Comment "SETUP" to get the 60FPS laptop setup + launch perks in your DMs before the clock hits 00:00!

#gta6 #gtavi #ps5 #gamingsetup
  ```
- **Poco F7 First-Comment Trigger (Post from 2nd phone):**
  `"See y'all on the other side 🫡 SETUP"`

## Reel #4: 3 Hours to Midnight Launch Callout (Slot 4 — 03:00 Morocco (9:00 PM EST))
- **What to Film (8–12s on iPhone 60FPS):** Tight shot of the final countdown hours ticking down on the laptop display while tapping the DualSense triggers.
- **Native Reels Text Hook (Top Center):** `We made it. Playing GTA 6 on the laptop in T-minus 3 hours 🌴🔥`
- **Bottom Small Text:** `Live stream + setup method in bio 👇`
- **Location Tag:** `Miami, Florida` or `Los Angeles, California` (for US feed routing)
- **Instagram Reel Caption + Hashtags (Copy-Paste):**
  ```text
We actually made it 🌴💻 Comment "SETUP" for the live stream link + 60FPS laptop method!

#gta6 #gtavi #vicecity #ps5
  ```
- **Poco F7 First-Comment Trigger (Post from 2nd phone):**
  `"LET'S GOOOOO"`
