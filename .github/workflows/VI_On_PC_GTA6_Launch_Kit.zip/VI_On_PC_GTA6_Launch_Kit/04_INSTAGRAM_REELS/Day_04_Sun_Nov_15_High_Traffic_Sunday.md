# Day 4 (Sun, Nov 15) — High-Traffic Sunday Relatable Hooks — Instagram Reels Pack (`@vi.onpc`)
**Daily Goal:** Sunday has the highest screen time of the week in the US/UK. Hit relatable angles ('Living Room TV Taken' + 'No Capture Card OBS Streaming').
**ManyChat Trigger:** Make sure your ManyChat automation triggers on the keyword `SETUP` and replies with your landing page link.

## Reel #1: Living Room TV Taken POV (Slot 1 — 18:00 Morocco (12:00 PM EST))
- **What to Film (8–12s on iPhone 60FPS):** Walk past the living room TV into your bedroom, open your laptop on the desk/bed, and pick up your DualSense with the PS5 screen already running.
- **Native Reels Text Hook (Top Center):** `When your family thinks they're using the TV during GTA 6 launch week 💀`
- **Bottom Small Text:** `Good thing my PS5 streams straight to my laptop in 60FPS`
- **Location Tag:** `Miami, Florida` or `Los Angeles, California` (for US feed routing)
- **Instagram Reel Caption + Hashtags (Copy-Paste):**
  ```text
They can keep the living room TV all week 💀💻 Comment "SETUP" and I'll DM you how to play your PS5 on your laptop in 60FPS!

#gta6 #gtavi #ps5 #gamingsetup
  ```
- **Poco F7 First-Comment Trigger (Post from 2nd phone):**
  `"Bro this literally saved my marriage for next week 💀 SETUP"`

## Reel #2: Thumbstick Flick Latency Proof (Slot 2 — 21:00 Morocco (3:00 PM EST))
- **What to Film (8–12s on iPhone 60FPS):** Hold your DualSense right up against the bottom bezel of your laptop monitor and flick the camera left/right rapidly so viewers see 1:1 instant response.
- **Native Reels Text Hook (Top Center):** `'bUt tHeRe iS a 2 sEcOnD dElAy' — look at my thumbstick vs the screen 🤡`
- **Bottom Small Text:** `0ms wired setup is in my bio 👇`
- **Location Tag:** `Miami, Florida` or `Los Angeles, California` (for US feed routing)
- **Instagram Reel Caption + Hashtags (Copy-Paste):**
  ```text
Where is the delay at?? 🤡🎮 When you wire your PS5 and DualSense properly, it's instant.

Comment "SETUP" for the exact config + perks!

#gta6 #gtavi #ps5 #gaminglaptop
  ```
- **Poco F7 First-Comment Trigger (Post from 2nd phone):**
  `"Okay wait that actually looks instant, how do you wire it?"`

## Reel #3: Stream GTA 6 on OBS Without a Capture Card (Slot 3 — 00:00 Morocco (6:00 PM EST))
- **What to Film (8–12s on iPhone 60FPS):** Show OBS Studio open on your laptop capturing the PS Remote Play window at 60FPS with your mic audio bar moving.
- **Native Reels Text Hook (Top Center):** `How to stream GTA 6 from PS5 to Twitch/TikTok WITHOUT a $200 capture card 🎥💻`
- **Bottom Small Text:** `Full OBS + laptop method in bio`
- **Location Tag:** `Miami, Florida` or `Los Angeles, California` (for US feed routing)
- **Instagram Reel Caption + Hashtags (Copy-Paste):**
  ```text
Save your $200—you don't need a capture card to stream or clip GTA 6 on your laptop 🎥💻

Comment "SETUP" and I'll DM you the exact OBS + laptop setup!

#gta6 #gtavi #streamer #gamingsetup
  ```
- **Poco F7 First-Comment Trigger (Post from 2nd phone):**
  `"Wait so OBS just captures the laptop window directly at 60fps?? SETUP"`

## Reel #4: 3D Audio + DualSense Haptics on PC (Slot 4 — 03:00 Morocco (9:00 PM EST - Auto-Scheduled))
- **What to Film (8–12s on iPhone 60FPS):** Plug your gaming headset into the bottom of the DualSense controller while the DualSense is connected to the laptop via USB-C.
- **Native Reels Text Hook (Top Center):** `PSA: Plug your DualSense into your laptop with USB-C for full vibration & 3D audio 🎧🔥`
- **Bottom Small Text:** `Bluetooth cuts haptics • Full setup in bio`
- **Location Tag:** `Miami, Florida` or `Los Angeles, California` (for US feed routing)
- **Instagram Reel Caption + Hashtags (Copy-Paste):**
  ```text
Always use USB-C instead of Bluetooth on your laptop for full DualSense haptics 🎧🔥

Comment "SETUP" for my full launch-week laptop checklist!

#gta6 #gtavi #dualsense #ps5
  ```
- **Poco F7 First-Comment Trigger (Post from 2nd phone):**
  `"Didn't know the headphone jack on the controller works through the laptop too!"`
