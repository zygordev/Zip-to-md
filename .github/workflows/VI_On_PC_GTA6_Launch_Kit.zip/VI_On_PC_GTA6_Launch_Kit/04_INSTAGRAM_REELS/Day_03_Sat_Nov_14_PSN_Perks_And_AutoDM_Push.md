# Day 3 (Sat, Nov 14) — Weekend Traffic + PSN Perks Conversion Push — Instagram Reels Pack (`@vi.onpc`)
**Daily Goal:** Saturday US/UK gaming traffic is huge. Push viewers hard toward your bio link & ManyChat DM for the 60FPS setup + PSN Store / Gear Perks.
**ManyChat Trigger:** Make sure your ManyChat automation triggers on the keyword `SETUP` and replies with your landing page link.

## Reel #1: The 10-Second 3-Step Formula (Slot 1 — 18:00 Morocco (12:00 PM EST))
- **What to Film (8–12s on iPhone 60FPS):** 3 fast 3-second cuts: (1) PS5 with LAN cable plugged in, (2) Laptop screen launching Sony Remote Play, (3) DualSense wired via USB-C.
- **Native Reels Text Hook (Top Center):** `How to play your PS5 copy of GTA 6 on your laptop in 3 steps ⚡💻`
- **Bottom Small Text:** `Full guide + PSN Store perks in bio 👇`
- **Location Tag:** `Miami, Florida` or `Los Angeles, California` (for US feed routing)
- **Instagram Reel Caption + Hashtags (Copy-Paste):**
  ```text
3 steps to run your PS5 copy of GTA 6 on your laptop at 60FPS ⚡💻

Comment "SETUP" and I'll DM you the links + launch week PSN perks instantly!

#gta6 #gtavi #ps5 #gamingsetup
  ```
- **Poco F7 First-Comment Trigger (Post from 2nd phone):**
  `"SETUP"`

## Reel #2: Hide the Annoying Connection Popup Trick (Slot 2 — 21:00 Morocco (3:00 PM EST))
- **What to Film (8–12s on iPhone 60FPS):** On your PS5 settings screen (mirrored on the laptop), go to Settings -> System -> Remote Play -> toggle ON 'Hide Remote Play Connection Status'.
- **Native Reels Text Hook (Top Center):** `Turn THIS setting on before recording or streaming GTA 6 on your laptop 👀`
- **Bottom Small Text:** `Hides the ugly connection banner • More tips in bio`
- **Location Tag:** `Miami, Florida` or `Los Angeles, California` (for US feed routing)
- **Instagram Reel Caption + Hashtags (Copy-Paste):**
  ```text
Turn this hidden setting ON before launch night 👀🔥 Comment "SETUP" for my full 60FPS laptop guide + PSN perks!

#gta6 #gtavi #ps5 #gamingsetup
  ```
- **Poco F7 First-Comment Trigger (Post from 2nd phone):**
  `"Bro I hated that top left notification popup, didn't know you could turn it off!"`

## Reel #3: Launch Prep Desk + PSN Perks Callout (Slot 3 — 00:00 Morocco (6:00 PM EST))
- **What to Film (8–12s on iPhone 60FPS):** Show your laptop with the GTA 6 countdown screen, your DualSense controller, and your headset on the desk.
- **Native Reels Text Hook (Top Center):** `Pre-loaded ✅ Laptop locked at 60FPS ✅ Ready for Nov 19 🔥`
- **Bottom Small Text:** `Check bio for setup guide + launch week PSN perks`
- **Location Tag:** `Miami, Florida` or `Los Angeles, California` (for US feed routing)
- **Instagram Reel Caption + Hashtags (Copy-Paste):**
  ```text
5 days left until launch night 🔥💻 Comment "SETUP" and I'll DM you the laptop setup checklist + PSN Store perks!

#gta6 #gtavi #ps5setup #gaming
  ```
- **Poco F7 First-Comment Trigger (Post from 2nd phone):**
  `"SETUP"`

## Reel #4: 5GHz Wi-Fi vs Ethernet Speed Test (Slot 4 — 03:00 Morocco (9:00 PM EST - Auto-Scheduled))
- **What to Film (8–12s on iPhone 60FPS):** Show a fast internet speed test on your laptop screen, then cut straight to smooth 60FPS gameplay with your DualSense.
- **Native Reels Text Hook (Top Center):** `How fast does your Wi-Fi need to be to play GTA 6 on a laptop? 📶💻`
- **Bottom Small Text:** `15 Mbps+ = Smooth 60FPS • Full test in bio`
- **Location Tag:** `Miami, Florida` or `Los Angeles, California` (for US feed routing)
- **Instagram Reel Caption + Hashtags (Copy-Paste):**
  ```text
You only need 15 Mbps+ on 5GHz Wi-Fi for smooth 60FPS 📶💻 Comment "SETUP" for the full latency guide + perks!

#gta6 #gtavi #gaminglaptop #ps5
  ```
- **Poco F7 First-Comment Trigger (Post from 2nd phone):**
  `"What if my router is in the living room and my laptop is in my bedroom?"`
