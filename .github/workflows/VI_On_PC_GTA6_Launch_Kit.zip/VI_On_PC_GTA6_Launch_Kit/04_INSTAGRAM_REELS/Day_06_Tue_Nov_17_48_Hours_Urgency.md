# Day 6 (Tue, Nov 17) — 48 Hours Left Urgency & PSN Perks Blitz — Instagram Reels Pack (`@vi.onpc`)
**Daily Goal:** Create massive FOMO 48 hours before launch. Tell viewers to set up their laptop NOW before PSN servers get hammered on launch night.
**ManyChat Trigger:** Make sure your ManyChat automation triggers on the keyword `SETUP` and replies with your landing page link.

## Reel #1: 48 Hours Left Server Warning (Slot 1 — 18:00 Morocco (12:00 PM EST))
- **What to Film (8–12s on iPhone 60FPS):** Zoom in on the 48-hour GTA VI countdown timer on your laptop screen, then show the PS Remote Play account login screen.
- **Native Reels Text Hook (Top Center):** `⚠️ 48 HOURS LEFT: Link your PS5 to your laptop TODAY before PSN servers crash on launch night`
- **Bottom Small Text:** `Takes 2 minutes • Step-by-step in bio 👇`
- **Location Tag:** `Miami, Florida` or `Los Angeles, California` (for US feed routing)
- **Instagram Reel Caption + Hashtags (Copy-Paste):**
  ```text
⚠️ 48 HOURS LEFT: Link your PS5 to your laptop TODAY before PSN servers get slammed on launch night!

Comment "SETUP" and I'll DM you the 2-minute checklist + PSN perks.

#gta6 #gtavi #ps5 #gamingsetup
  ```
- **Poco F7 First-Comment Trigger (Post from 2nd phone):**
  `"Actually smart af, PSN login always lags on huge launch nights. SETUP"`

## Reel #2: Quick Screen Tour of Your Link Hub & Perks (Slot 2 — 21:00 Morocco (3:00 PM EST))
- **What to Film (8–12s on iPhone 60FPS):** Hold your Poco F7 or iPhone in front of your laptop desk showing your landing page (`gta6_remote_play_hub.html`) scrolling through the 3 setup tabs and the PSN/Gear perks.
- **Native Reels Text Hook (Top Center):** `Put my entire 60FPS GTA 6 laptop setup + launch week PSN perks on one page for y'all 💻🎁`
- **Bottom Small Text:** `Tap the link in my bio or comment SETUP 👇`
- **Location Tag:** `Miami, Florida` or `Los Angeles, California` (for US feed routing)
- **Instagram Reel Caption + Hashtags (Copy-Paste):**
  ```text
Put all 3 laptop setup methods + launch week PSN & controller perks on one clean page for y'all 💻🎁

Comment "SETUP" and I'll DM it right now!

#gta6 #gtavi #ps5setup #gaming
  ```
- **Poco F7 First-Comment Trigger (Post from 2nd phone):**
  `"SETUP"`

## Reel #3: The 4-Point Launch Readiness Checklist (Slot 3 — 00:00 Morocco (6:00 PM EST))
- **What to Film (8–12s on iPhone 60FPS):** Point with your finger to 4 things on your desk: 1. PS5 updated, 2. GTA 6 pre-loaded, 3. Ethernet plugged in, 4. Laptop Remote Play set to 60FPS.
- **Native Reels Text Hook (Top Center):** `GTA 6 Laptop Launch Checklist (48 Hours Left) ✅💻`
- **Bottom Small Text:** `Missing anything? Full checklist in bio`
- **Location Tag:** `Miami, Florida` or `Los Angeles, California` (for US feed routing)
- **Instagram Reel Caption + Hashtags (Copy-Paste):**
  ```text
How many do you have checked off before Thursday? ✅💻 Comment "SETUP" for the full interactive checklist + perks!

#gta6 #gtavi #ps5 #gamingsetup
  ```
- **Poco F7 First-Comment Trigger (Post from 2nd phone):**
  `"4/4 ready for Vice City 🔥"`

## Reel #4: Late-Night Vice City Desk Vibe (Slot 4 — 03:00 Morocco (9:00 PM EST - Auto-Scheduled))
- **What to Film (8–12s on iPhone 60FPS):** Aesthetic 8-second shot of your glowing laptop and DualSense with the GTA VI countdown clock ticking down.
- **Native Reels Text Hook (Top Center):** `Last 2 nights of sleep before Vice City on the laptop 🌴💻`
- **Bottom Small Text:** `60FPS setup + PSN perks in bio`
- **Location Tag:** `Miami, Florida` or `Los Angeles, California` (for US feed routing)
- **Instagram Reel Caption + Hashtags (Copy-Paste):**
  ```text
Sleep while you still can 🌴💻 Comment "SETUP" to get your laptop ready before Thursday!

#gta6 #gtavi #vicecity #gaming
  ```
- **Poco F7 First-Comment Trigger (Post from 2nd phone):**
  `"Taking Thursday and Friday off work for this 💀"`
