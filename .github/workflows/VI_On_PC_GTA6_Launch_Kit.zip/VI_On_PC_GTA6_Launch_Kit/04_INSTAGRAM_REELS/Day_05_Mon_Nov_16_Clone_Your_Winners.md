# Day 5 (Mon, Nov 16) — Clone Your Top 2 Viral Winners (3 Days to Launch) — Instagram Reels Pack (`@vi.onpc`)
**Daily Goal:** Look at your analytics from Thu–Sun. Take your #1 and #2 highest-viewed clips and re-film them with even tighter 8-second pacing and stronger CTAs.
**ManyChat Trigger:** Make sure your ManyChat automation triggers on the keyword `SETUP` and replies with your landing page link.

## Reel #1: Part 2 of Your #1 Most-Viewed Clip (3 Days Left Edition) (Slot 1 — 18:00 Morocco (12:00 PM EST))
- **What to Film (8–12s on iPhone 60FPS):** Re-shoot the exact visual angle of your best-performing video so far, starting with the 3-day countdown on the laptop screen.
- **Native Reels Text Hook (Top Center):** `3 DAYS LEFT: Still the smartest way to play GTA 6 on a laptop at 60FPS 💻🔥`
- **Bottom Small Text:** `Requires your own PS5 + game • Setup in bio`
- **Location Tag:** `Miami, Florida` or `Los Angeles, California` (for US feed routing)
- **Instagram Reel Caption + Hashtags (Copy-Paste):**
  ```text
3 DAYS LEFT 💻🔥 Set your laptop up in 3 minutes tonight so you're ready for midnight launch.

Comment "SETUP" and I'll DM you the link!

#gta6 #gtavi #ps5 #gamingsetup
  ```
- **Poco F7 First-Comment Trigger (Post from 2nd phone):**
  `"SETUP"`

## Reel #2: The 'Stop Buying Fake PC Keys' Warning (Massive Trust Builder) (Slot 2 — 21:00 Morocco (3:00 PM EST))
- **What to Film (8–12s on iPhone 60FPS):** Shake your head at the camera/laptop, then point to your PS5 and the official Sony Remote Play app on your laptop screen.
- **Native Reels Text Hook (Top Center):** `PSA: Stop falling for fake 'GTA 6 PC download' links 💀 There is NO PC version!`
- **Bottom Small Text:** `The ONLY legit way on laptop is streaming your own PS5 👇`
- **Location Tag:** `Miami, Florida` or `Los Angeles, California` (for US feed routing)
- **Instagram Reel Caption + Hashtags (Copy-Paste):**
  ```text
Stop falling for fake PC links 💀 There is NO PC port yet—the only legit way to play on a laptop is streaming your own PS5.

Comment "SETUP" and I'll DM you the official Sony method!

#gta6 #gtavi #ps5 #pcgaming
  ```
- **Poco F7 First-Comment Trigger (Post from 2nd phone):**
  `"Realest account on here, everyone else is posting fake PC emulators"`

## Reel #3: Part 2 of Your #2 Most-Viewed Clip (Slot 3 — 00:00 Morocco (6:00 PM EST))
- **What to Film (8–12s on iPhone 60FPS):** Re-film your 2nd highest-performing video with a fresh song and faster 2-second cuts between your PS5, router, and laptop.
- **Native Reels Text Hook (Top Center):** `How I got my PS5-to-laptop connection from 30fps blurry -> 1080p 60FPS crisp ⚡`
- **Bottom Small Text:** `Copy my exact settings in bio 👇`
- **Location Tag:** `Miami, Florida` or `Los Angeles, California` (for US feed routing)
- **Instagram Reel Caption + Hashtags (Copy-Paste):**
  ```text
Night and day difference ⚡💻 Comment "SETUP" to get my exact 1080p 60FPS laptop settings DM'd to you!

#gta6 #gtavi #ps5 #gamingsetup
  ```
- **Poco F7 First-Comment Trigger (Post from 2nd phone):**
  `"SETUP"`

## Reel #4: Late-Night Comment Q&A Video Reply (Slot 4 — 03:00 Morocco (9:00 PM EST - Auto-Scheduled))
- **What to Film (8–12s on iPhone 60FPS):** Pick a new question in your comments and film a 9-second visual answer pointing to your bio link.
- **Native Reels Text Hook (Top Center):** `Answering your top question before GTA 6 launch night 👇💻`
- **Bottom Small Text:** `Full setup hub in bio`
- **Location Tag:** `Miami, Florida` or `Los Angeles, California` (for US feed routing)
- **Instagram Reel Caption + Hashtags (Copy-Paste):**
  ```text
Works on both Windows laptops and MacBooks 💻🔥 Comment "SETUP" for the step-by-step link!

#gta6 #gtavi #macbook #ps5
  ```
- **Poco F7 First-Comment Trigger (Post from 2nd phone):**
  `"Wait it works on MacBook Air too?! Clutch"`
