# VI On PC (@vi.onpc) — Master GTA 6 Launch & Pre-Launch CPA Playbook

Welcome to your all-in-one launch folder. Everything is organized by platform and by day (`Day 1: Thu Nov 12` through `Day 8: Thu Nov 19 Launch Day`) so you can film in 25 minutes, copy-paste your titles/descriptions/hashtags, and collect Tier-1 OGAds leads starting **before** GTA 6 even unlocks.

## Folder Map
- **`00_START_HERE_MASTER_PLAYBOOK/`**
  - `01_Tier1_Geo_And_Anti_Shadowban_Bible.md` — How to lock your views into US, UK, Canada, Australia & Western Europe ($1.50–$3.50/lead) from Morocco and avoid shadowbans.
  - `02_Pre_Launch_Lead_Magnet_Strategy.md` — How to make viewers click your bio link and complete OGAds offers *before* Nov 19 (Pre-Launch Latency Toolkit + PSN Store Launch Perks).
  - `03_Batch_Filming_And_Automation_System.md` — How to shoot 4 clips/day in 20 minutes using your iPhone, Poco F7, Laptop, and PS5 + ManyChat DM automation.
- **`01_PROFILE_AND_ASSETS/`**
  - `Copy_Paste_Bios_And_Keywords.md` — Exact display names, bios, and ranking keyword blocks for YouTube, TikTok, and Instagram.
  - `VI_On_PC_Profile_Avatar.jpg` — Your 1:1 neon DualSense + Laptop profile picture.
  - `7_Day_Schedule_Emploi_Du_Temps.jpg` — High-res visual timetable (`18:00`, `21:00`, `00:00`, `03:00` Morocco time).
- **`02_YOUTUBE_SHORTS/`** — 8 daily `.md` files (`Day_01` to `Day_08`) with 4 Shorts per day: camera instructions, on-screen headlines, titles, SEO descriptions, pinned comments, and tags.
- **`03_TIKTOK/`** — 8 daily `.md` files (`Day_01` to `Day_08`) with 4 TikToks per day: visual hooks, native text overlays, captions, hashtags, and Poco F7 first-comment triggers.
- **`04_INSTAGRAM_REELS/`** — 8 daily `.md` files (`Day_01` to `Day_08`) with 4 Reels per day: hooks, captions, ManyChat `SETUP` triggers, and story callouts.
- **`05_HIGH_CONVERTING_LANDING_PAGE/`**
  - `index.html` — Ready-to-upload mobile-first landing page (upload directly to Netlify Drop, Vercel, or GitHub Pages).

## Official Reference Links Used Across Your Funnel
- Official GTA VI Page (Rockstar Games): https://www.rockstargames.com/VI
- Official GTA VI PS5 Pre-Load Announcement: https://www.rockstargames.com/newswire/article/89834o94713o21/pre-load-grand-theft-auto-vi-now
- Official PlayStation Store GTA VI Page: https://www.playstation.com/en-us/games/grand-theft-auto-vi/
- Official Sony PS Remote Play App (PC/Mac): https://remoteplay.dl.playstation.net/remoteplay/lang/en/1100001.html
- Official Sony PS Remote Play Windows Specs: https://remoteplay.dl.playstation.net/remoteplay/lang/en/1100007.html
- Official PS5 Remote Play Settings Guide: https://www.playstation.com/en-us/support/games/remote-play-settings/
