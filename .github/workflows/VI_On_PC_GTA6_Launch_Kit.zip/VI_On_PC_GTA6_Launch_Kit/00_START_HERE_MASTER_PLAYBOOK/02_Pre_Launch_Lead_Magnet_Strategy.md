# How to Get OGAds Leads BEFORE GTA 6 Launches (Nov 12 – Nov 18)

You don't have to wait until November 19 to make money. People clicking your bio link **right now** want two things before launch night:
1. **They want their laptop ready & tested at 1080p 60FPS** so they can play their PS5 copy on their laptop the second GTA 6 unlocks.
2. **They want PSN Store credit, PS Plus, or controller gear** before launch night (because GTA VI + Ultimate Edition upgrades and accessories cost money).

## The 3 Pre-Launch Lead Angles (Put These in Your Bio & ManyChat Now)

### Angle 1: The "Pre-Launch 60FPS Laptop Config + Latency Test"
- **Why they click today:** Viewers see your laptop running the PS5 dashboard / GTA 6 Pre-Load timer or GTA 5 at 60FPS with a DualSense controller. They want to set up and test their own laptop *before* launch night so they don't waste launch day troubleshooting lag.
- **How it converts on your page:** They land on your page, grab the 3-step setup, and immediately see your **"Pre-Launch Network Optimizer / Mobile Companion App"** CPI offer and **"PSN Store Launch Perks"** offer right underneath.

### Angle 2: The "Launch-Week PSN Store & Gear Perks" Hook
- **Why they click today:** Every gamer watching GTA 6 clips between Nov 12 and Nov 18 is either trying to buy the game on PS5, upgrade to the Ultimate Edition, or grab a USB-C DualSense cable / headset for their desk.
- **What you say in yourPinned Comment / Bio:**
  > `"Exact 60FPS laptop setup method + Launch-Week PSN Store & Gear Perks are live in my bio link 👇"`

### Angle 3: The ManyChat "SETUP" Auto-DM Funnel (Starts Day 1 or Day 2)
When someone comments `SETUP` on your Instagram Reel, your ManyChat bot instantly sends them this DM:

```text
Yo! Here is the exact method I use to run my PS5 copy of GTA 6 on my laptop at a locked 60FPS with zero input lag 💻🔥

1️⃣ Official 60FPS Laptop Setup + Latency Settings
2️⃣ Launch-Week PSN Store & Controller Perks (Optional)

Tap here to open the setup hub 👇
[YOUR_LANDING_PAGE_LINK]

(Note: Uses Sony's official console-to-PC method — requires your own PS5 + game!)
```

## Best OGAds Offers to Enable in Your Dashboard This Week
Log into OGAds and prioritize these 3 offer types for Tier-1 mobile traffic (iPhone + Android):
1. **Free Mobile Game / App Install (CPI) ($1.20 – $2.80 per install):** Highest conversion rate (12%–20%) because users just install a free app from the official App Store / Google Play and open it for 30 seconds.
2. **PlayStation Store / Gaming Reward Surveys ($1.50 – $3.50 per lead):** Ultra-relevant to viewers preparing for GTA 6 launch week.
3. **Gaming Gear / Controller Sweepstakes (SOI - Single Opt-In Email/Zip) ($1.00 – $2.20 per lead):** Quick 1-page email or zip code submit.
