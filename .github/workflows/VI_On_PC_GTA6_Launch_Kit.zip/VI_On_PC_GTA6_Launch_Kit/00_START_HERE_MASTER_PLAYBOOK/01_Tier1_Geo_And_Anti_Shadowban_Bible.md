# Tier-1 Country Targeting & Anti-Shadowban Bible

## 1. How to Force US / UK / Canada / Australia Views From Morocco
OGAds pays **$1.20 to $3.50+ per lead** in Tier-1 countries (United States, United Kingdom, Canada, Australia, Germany) versus **$0.10 to $0.25** in North Africa/MENA. Here is how each platform decides where to push your videos:

1. **YouTube Shorts (Easiest to Target Globally):**
   - Go to **YouTube Studio -> Settings -> Channel -> Basic Info** and set **Country of residence** to **United States**.
   - On every upload (under **Show More -> Language and captions certification**), set **Video language** to **English (United States)**.
   - YouTube routes Shorts based on **language + metadata**, NOT your SIM card. Speaking/writing 100% in American English guarantees US/UK Shorts shelf placement.
2. **Instagram Reels (Fresh Account Rules):**
   - Never use an old account with Moroccan followers (Instagram tests Reels on existing followers first).
   - Set your iPhone **Settings -> General -> Language & Region** to **English (United States)** and Region to **United States**.
   - When posting a Reel, **NEVER tag a local Moroccan location**. Either leave location blank or tag `Miami, Florida` (the real-life Vice City), `Los Angeles, California`, or `New York, New York`.
3. **TikTok (SIM & Region Rules):**
   - TikTok checks your SIM card country code first.
   - **Best Move:** Take the Moroccan SIM card OUT of the phone you use to post on TikTok (or use an inactive US SIM / eSIM on Wi-Fi) with device region set to **United States** and language set to **English**.
   - Use American gaming slang (`"wait till 2028"`, `"0ms input lag"`, `"living room TV"`, `"60fps desk setup"`) and trending US audio tracks at `5%–8%` volume under your original clip audio.

## 2. Posting Schedule (Peak Tier-1 Hours Mapped to Morocco Time)
Post **4 times per day** spaced 3 hours apart so you catch US East Coast, US West Coast, and UK peak scrolling windows:

| Slot | Morocco Time (UTC+1) | US Eastern Time (EST) | Target Tier-1 Audience Window |
| :--- | :--- | :--- | :--- |
| **Slot 1** | **18:00 (6:00 PM)** | 12:00 PM EST | US Lunch Break + UK Evening Peak (5:00 PM UK) |
| **Slot 2** | **21:00 (9:00 PM)** | 3:00 PM EST | US After-School / Work + UK Late Night (8:00 PM UK) |
| **Slot 3** | **00:00 (12:00 AM)** | 6:00 PM EST | US Prime-Time Evening Scroll |
| **Slot 4** | **03:00 (3:00 AM)** *(Schedule in app)* | 9:00 PM EST | US Late-Night Gaming Scroll + West Coast Prime Time (6:00 PM PST) |

## 3. Zero-Shadowban Rules (Never Break These)
- **Never use banned trigger words:** Never write `crack`, `free download`, `key generator`, `leaked gameplay`, `bypass`, or `hack` in titles, captions, or on-screen text.
- **No watermark cross-posting:** Film raw vertical video (`1080x1920`, `60fps`) on your iPhone camera app. Never download a watermarked TikTok video and upload it to Reels or Shorts.
- **Keep hashtags to 4–5 max:** Tag stuffing (15+ tags) triggers spam filters. Stick to `#gta6 #ps5 #gamingsetup #gtavi`.
- **Keep links in your Bio / ManyChat DM only:** Never paste raw OGAds tracking URLs directly inside video comments or descriptions. Point viewers to your clean landing page in your bio.
