# 20-Minute Daily Batch Filming & Automation System

## Your Hardware Roles
- **PS5:** Connected to your router via Ethernet cable (if possible), running the [GTA VI Pre-Load screen](https://www.rockstargames.com/newswire/article/89834o94713o21/pre-load-grand-theft-auto-vi-now) and a fast-paced PS5 game (like GTA 5, Spider-Man 2, or Cyberpunk) for 60FPS latency demonstrations.
- **Laptop:** Running [Sony PS Remote Play](https://remoteplay.dl.playstation.net/remoteplay/lang/en/1100001.html) in a full-screen or side-by-side window + DualSense wired via USB-C.
- **iPhone:** Your main camera + logged into your 3 main `@vi.onpc` accounts (YouTube Shorts, TikTok, Instagram Reels). Set camera to **1080p at 60 fps**.
- **Poco F7:** Your "First Comment & Engagement Trigger" phone. The second a video goes live on `@vi.onpc`, use a separate personal account on your Poco F7 to drop a spicy question in the comments (`"Wait how is your laptop running this at 60fps without overheating?!"`), then reply to it from your iPhone.

## How to Film All 4 Daily Clips in 15 Minutes
1. Sit at your desk with room lights dimmed and your laptop keyboard + screen glowing.
2. Record **4 raw vertical clips (8 to 13 seconds each)** on your iPhone following that day's `.md` file in `02_YOUTUBE_SHORTS`, `03_TIKTOK`, and `04_INSTAGRAM_REELS`.
3. **Never talk for 2 minutes**—either use **fast 1-sentence voiceover** or **no voiceover (just controller clicks + game audio + trending background sound at 8% volume)** with bold on-screen text at the top.
4. Schedule or post at **18:00, 21:00, 00:00, and 03:00 Morocco time**.
