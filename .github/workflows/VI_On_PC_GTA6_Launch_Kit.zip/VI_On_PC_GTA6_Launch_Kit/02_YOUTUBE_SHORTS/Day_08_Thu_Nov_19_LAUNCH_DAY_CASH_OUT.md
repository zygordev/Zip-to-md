# Day 8 (Thu, Nov 19) — OFFICIAL GTA 6 LAUNCH DAY CASHOUT — YouTube Shorts Pack (`@vi.onpc`)
**Daily Goal:** Switch your landing page to LIVE NOW mode! Show real GTA 6 Vice City gameplay running on your laptop screen with your DualSense in frame.
**Upload Settings:** Select `No, it's not made for kids` | Video Language: `English (United States)`

## Short #1: ACTUAL GTA 6 Running on My Laptop Flex (Mega Viral Clip) (Slot 1 — 18:00 Morocco (12:00 PM EST))
- **What to Film (8–12s on iPhone 60FPS):** Show actual GTA 6 gameplay in Vice City running smoothly at 60FPS on your laptop screen, then pan out to show your DualSense controller and laptop keyboard.
- **Top On-Screen Headline:** `Playing my PS5 copy of GTA 6 on my laptop at 60FPS on Day 1 💀🌴`
- **Bottom Small Text:** `Exact 0-lag method + PSN perks in bio 👇`
- **YouTube Short Title:**
  ```text
  Playing GTA 6 on my laptop at 60FPS on Launch Day 💀🌴 #gta6 #gtavi #ps5 #gaminglaptop
  ```
- **YouTube Description:**
  ```text
Streaming my PS5 copy of GTA 6 straight to my laptop at 1080p 60FPS with zero lag.

Grab the exact 3-step setup + launch week PSN perks on @vi.onpc! (Requires your own PS5 + official game).
  ```
- **Pinned Comment (Paste Immediately After Uploading):**
  ```text
  Here is how I'm running my PS5 copy of GTA 6 on my laptop at 60FPS + launch week PSN perks: check my channel bio @vi.onpc 👇
  ```
- **Poco F7 First-Comment Trigger (Post from 2nd phone 60s after upload):**
  `"WAIT HOW IS IT SO SMOOTH ON A LAPTOP?! SETUP"`

## Short #2: Vice City Driving Latency Test on Laptop (Slot 2 — 21:00 Morocco (3:00 PM EST))
- **What to Film (8–12s on iPhone 60FPS):** Drive a fast car down Ocean Beach / Vice City neon streets on your laptop screen while keeping your hands + DualSense thumbsticks in the bottom half of the vertical frame.
- **Top On-Screen Headline:** `Look at the graphics & 0ms response on my laptop screen 🔥🚗`
- **Bottom Small Text:** `Full PS5-to-laptop setup in bio`
- **YouTube Short Title:**
  ```text
  GTA 6 60FPS latency test on my laptop desk setup 🔥🚗 #gta6 #gtavi #vicecity #ps5
  ```
- **YouTube Description:**
  ```text
Zero input lag driving through Vice City on my laptop via wired DualSense.

Full setup + live stream + perks on @vi.onpc!
  ```
- **Pinned Comment (Paste Immediately After Uploading):**
  ```text
  Want to play your PS5 copy on your laptop with zero lag? Full guide + PSN perks in my channel bio @vi.onpc 👇
  ```
- **Poco F7 First-Comment Trigger (Post from 2nd phone 60s after upload):**
  `"SETUP"`

## Short #3: Playing GTA 6 in Bed on Laptop POV (Slot 3 — 00:00 Morocco (6:00 PM EST))
- **What to Film (8–12s on iPhone 60FPS):** Film from bed with your laptop on your lap running GTA 6 via PS Remote Play while holding the DualSense.
- **Top On-Screen Headline:** `Playing GTA 6 from bed on my laptop while the TV is taken 💀🛌`
- **Bottom Small Text:** `Comment SETUP for the 60FPS method 👇`
- **YouTube Short Title:**
  ```text
  Playing GTA 6 in bed on my laptop at 60FPS 💀🛌 #gta6 #gtavi #ps5 #gaminglaptop
  ```
- **YouTube Description:**
  ```text
Living room TV is taken, so I'm running my PS5 copy of GTA 6 on my laptop in bed at 60FPS.

Full setup guide on @vi.onpc!
  ```
- **Pinned Comment (Paste Immediately After Uploading):**
  ```text
  Play your PS5 copy anywhere in the house on your laptop! Full 60FPS setup + PSN perks in my bio @vi.onpc 👇
  ```
- **Poco F7 First-Comment Trigger (Post from 2nd phone 60s after upload):**
  `"Doing this tonight 100% SETUP"`

## Short #4: Launch Night Live Stream + Perks Recap (Slot 4 — 03:00 Morocco (9:00 PM EST - Auto-Scheduled))
- **What to Film (8–12s on iPhone 60FPS):** Show your laptop running GTA 6 + OBS Studio streaming live on your second window.
- **Top On-Screen Headline:** `We are LIVE playing GTA 6 on the laptop setup all night 🔴🌴`
- **Bottom Small Text:** `Stream link + 60FPS setup + PSN perks in bio 👇`
- **YouTube Short Title:**
  ```text
  Streaming GTA 6 all night from the laptop setup 🔴🌴 #gta6 #gtavi #livestream #ps5
  ```
- **YouTube Description:**
  ```text
Join the spoiler-delayed launch stream and grab the 60FPS laptop setup + gaming perks on @vi.onpc!
  ```
- **Pinned Comment (Paste Immediately After Uploading):**
  ```text
  Join the live stream + grab the 60FPS laptop method & PSN perks in my channel bio @vi.onpc 👇
  ```
- **Poco F7 First-Comment Trigger (Post from 2nd phone 60s after upload):**
  `"SETUP"`
