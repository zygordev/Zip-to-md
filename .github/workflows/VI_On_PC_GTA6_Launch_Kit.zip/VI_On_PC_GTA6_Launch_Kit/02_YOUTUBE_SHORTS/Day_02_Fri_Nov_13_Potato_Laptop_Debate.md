# Day 2 (Fri, Nov 13) — The 'Potato Laptop' Debate & Settings Bait — YouTube Shorts Pack (`@vi.onpc`)
**Daily Goal:** Spark massive comment debates ('How is a basic laptop running this at 60fps?!') to skyrocket watch time and drive bio clicks.
**Upload Settings:** Select `No, it's not made for kids` | Video Language: `English (United States)`

## Short #1: Task Manager 5% CPU Flex (Slot 1 — 18:00 Morocco (12:00 PM EST))
- **What to Film (8–12s on iPhone 60FPS):** Show Windows Task Manager open on the left side of your laptop screen (showing tiny CPU/GPU usage) while a fast 60FPS PS5 game runs in the window on the right.
- **Top On-Screen Headline:** `Running 60FPS on a regular laptop while CPU sits at 5% 💀💻`
- **Bottom Small Text:** `Your PS5 does 100% of the work • Setup in bio`
- **YouTube Short Title:**
  ```text
  When your laptop CPU sits at 5% running 60FPS console graphics 💀💻 #gta6 #ps5 #gaminglaptop #gtavi
  ```
- **YouTube Description:**
  ```text
Because your PS5 renders the game and streams it locally to your laptop at 1080p 60FPS, your laptop fans don't even spin up.

Full setup guide + launch perks on @vi.onpc!
  ```
- **Pinned Comment (Paste Immediately After Uploading):**
  ```text
  Even a basic Windows 10/11 or Mac laptop works if you have a PS5! Full 60FPS setup + PSN perks in my bio @vi.onpc 👇
  ```
- **Poco F7 First-Comment Trigger (Post from 2nd phone 60s after upload):**
  `"Bro had me thinking his office laptop had an RTX 5090 in it 😭 smart method though"`

## Short #2: The 2 Hidden 60FPS Settings (Slot 2 — 21:00 Morocco (3:00 PM EST))
- **What to Film (8–12s on iPhone 60FPS):** Zoom in on the Sony PS Remote Play PC settings menu: click Resolution -> 1080p, and Frame Rate -> High. Then pan to smooth gameplay.
- **Top On-Screen Headline:** `Stop playing on your laptop with blurry graphics. Change these 2 settings 👇`
- **Bottom Small Text:** `Save this before GTA 6 drops on Nov 19`
- **YouTube Short Title:**
  ```text
  Change these 2 laptop settings BEFORE GTA 6 drops on Nov 19 ⚡ #gta6 #ps5 #gamingsetup #gtavi
  ```
- **YouTube Description:**
  ```text
Default settings cap your stream at 720p 30fps. Switch Frame Rate to High and Resolution to 1080p for a locked 60FPS.

Full zero-lag checklist + PSN perks on @vi.onpc!
  ```
- **Pinned Comment (Paste Immediately After Uploading):**
  ```text
  Full step-by-step zero-lag setup + launch week PSN perks are in my channel bio @vi.onpc 👇
  ```
- **Poco F7 First-Comment Trigger (Post from 2nd phone 60s after upload):**
  `"Thank you!! Mine was stuck on Standard frame rate this whole time"`

## Short #3: Video Reply to Top Day-1 Comment (Slot 3 — 00:00 Morocco (6:00 PM EST))
- **What to Film (8–12s on iPhone 60FPS):** Use the native Video Reply feature to reply to the top question from Day 1 while showing your PS5 Ethernet cable + laptop USB-C DualSense setup.
- **Top On-Screen Headline:** `Replying to @comment: Yes, any Windows 10/11 or Mac laptop works 💻✅`
- **Bottom Small Text:** `Requires your own PS5 + game • Link in bio`
- **YouTube Short Title:**
  ```text
  Does this GTA 6 laptop setup work on a cheap laptop? 💻🤔 #gta6 #ps5 #gaminglaptop #gtavi
  ```
- **YouTube Description:**
  ```text
Answering your top question: you only need Windows 10/11 or Mac, 2GB RAM, and your PS5 on a fast connection.

Full guide + perks on @vi.onpc!
  ```
- **Pinned Comment (Paste Immediately After Uploading):**
  ```text
  Check if your laptop is ready + grab launch week PSN perks in my channel bio @vi.onpc 👇
  ```
- **Poco F7 First-Comment Trigger (Post from 2nd phone 60s after upload):**
  `"Just tested this on my school laptop and it actually runs smooth af"`

## Short #4: Dark Room Vice City Neon POV (Slot 4 — 03:00 Morocco (9:00 PM EST - Auto-Scheduled))
- **What to Film (8–12s on iPhone 60FPS):** POV filming over your shoulder in a dark room as you play at 60FPS on the laptop screen with pink/cyan lighting.
- **Top On-Screen Headline:** `6 days left until Vice City takes over this laptop desk 🌴💻`
- **Bottom Small Text:** `Setup guide + PSN perks in bio`
- **YouTube Short Title:**
  ```text
  6 days until Vice City on the laptop setup 🌴💻 #gta6 #gtavi #vicecity #gamingsetup
  ```
- **YouTube Description:**
  ```text
6 days left until November 19. Get your PS5-to-laptop desk setup ready tonight.

Setup link + perks on @vi.onpc!
  ```
- **Pinned Comment (Paste Immediately After Uploading):**
  ```text
  Grab the 60FPS laptop setup + optional PSN Store & controller perks in my bio @vi.onpc 👇
  ```
- **Poco F7 First-Comment Trigger (Post from 2nd phone 60s after upload):**
  `"This desk vibe is elite, Nov 19 cannot come fast enough"`
