# Day 3 (Sat, Nov 14) — Weekend Traffic + PSN Perks Conversion Push — YouTube Shorts Pack (`@vi.onpc`)
**Daily Goal:** Saturday US/UK gaming traffic is huge. Push viewers hard toward your bio link & ManyChat DM for the 60FPS setup + PSN Store / Gear Perks.
**Upload Settings:** Select `No, it's not made for kids` | Video Language: `English (United States)`

## Short #1: The 10-Second 3-Step Formula (Slot 1 — 18:00 Morocco (12:00 PM EST))
- **What to Film (8–12s on iPhone 60FPS):** 3 fast 3-second cuts: (1) PS5 with LAN cable plugged in, (2) Laptop screen launching Sony Remote Play, (3) DualSense wired via USB-C.
- **Top On-Screen Headline:** `How to play your PS5 copy of GTA 6 on your laptop in 3 steps ⚡💻`
- **Bottom Small Text:** `Full guide + PSN Store perks in bio 👇`
- **YouTube Short Title:**
  ```text
  Play your PS5 copy of GTA 6 on your laptop in 3 easy steps ⚡💻 #gta6 #ps5 #gamingsetup #gtavi
  ```
- **YouTube Description:**
  ```text
1. Enable Remote Play on PS5 + plug in LAN cable.
2. Set PC app to 1080p High (60FPS).
3. Wire DualSense via USB-C.

Full guide + PSN Store launch perks on @vi.onpc!
  ```
- **Pinned Comment (Paste Immediately After Uploading):**
  ```text
  Grab the official app link, zero-lag settings, and optional PSN Store launch perks in my bio @vi.onpc 👇
  ```
- **Poco F7 First-Comment Trigger (Post from 2nd phone 60s after upload):**
  `"SETUP"`

## Short #2: Hide the Annoying Connection Popup Trick (Slot 2 — 21:00 Morocco (3:00 PM EST))
- **What to Film (8–12s on iPhone 60FPS):** On your PS5 settings screen (mirrored on the laptop), go to Settings -> System -> Remote Play -> toggle ON 'Hide Remote Play Connection Status'.
- **Top On-Screen Headline:** `Turn THIS setting on before recording or streaming GTA 6 on your laptop 👀`
- **Bottom Small Text:** `Hides the ugly connection banner • More tips in bio`
- **YouTube Short Title:**
  ```text
  Turn on this hidden PS5 setting before GTA 6 launch night 👀🎮 #gta6 #ps5 #gamingsetup #gtavi
  ```
- **YouTube Description:**
  ```text
How to hide the 'Remote Play connected' banner so your laptop screen looks 100% clean for clips and streams.

Full setup hub on @vi.onpc!
  ```
- **Pinned Comment (Paste Immediately After Uploading):**
  ```text
  All my hidden 60FPS settings + launch week PSN & gear perks are linked in my channel bio @vi.onpc 👇
  ```
- **Poco F7 First-Comment Trigger (Post from 2nd phone 60s after upload):**
  `"Bro I hated that top left notification popup, didn't know you could turn it off!"`

## Short #3: Launch Prep Desk + PSN Perks Callout (Slot 3 — 00:00 Morocco (6:00 PM EST))
- **What to Film (8–12s on iPhone 60FPS):** Show your laptop with the GTA 6 countdown screen, your DualSense controller, and your headset on the desk.
- **Top On-Screen Headline:** `Pre-loaded ✅ Laptop locked at 60FPS ✅ Ready for Nov 19 🔥`
- **Bottom Small Text:** `Check bio for setup guide + launch week PSN perks`
- **YouTube Short Title:**
  ```text
  Pre-loaded and locked at 60FPS on the laptop desk 🔥💻 #gta6 #gtavi #ps5 #gamingsetup
  ```
- **YouTube Description:**
  ```text
Everything is dialed in for November 19. Check the link on @vi.onpc for the exact laptop setup and optional PSN Store & gaming gear perks!
  ```
- **Pinned Comment (Paste Immediately After Uploading):**
  ```text
  Grab the free 60FPS laptop setup + check out the optional PSN & controller perks in my bio @vi.onpc 👇
  ```
- **Poco F7 First-Comment Trigger (Post from 2nd phone 60s after upload):**
  `"SETUP"`

## Short #4: 5GHz Wi-Fi vs Ethernet Speed Test (Slot 4 — 03:00 Morocco (9:00 PM EST - Auto-Scheduled))
- **What to Film (8–12s on iPhone 60FPS):** Show a fast internet speed test on your laptop screen, then cut straight to smooth 60FPS gameplay with your DualSense.
- **Top On-Screen Headline:** `How fast does your Wi-Fi need to be to play GTA 6 on a laptop? 📶💻`
- **Bottom Small Text:** `15 Mbps+ = Smooth 60FPS • Full test in bio`
- **YouTube Short Title:**
  ```text
  Do you need crazy Wi-Fi to run GTA 6 on your laptop? 📶💻 #gta6 #ps5 #gaminglaptop #gtavi
  ```
- **YouTube Description:**
  ```text
Sony recommends at least 15 Mbps for smooth 60FPS console-to-laptop streaming. Plug your PS5 into Ethernet and use 5GHz Wi-Fi on your laptop!

Full guide on @vi.onpc.
  ```
- **Pinned Comment (Paste Immediately After Uploading):**
  ```text
  Full Wi-Fi optimization steps + gaming perks are linked in my channel bio @vi.onpc 👇
  ```
- **Poco F7 First-Comment Trigger (Post from 2nd phone 60s after upload):**
  `"What if my router is in the living room and my laptop is in my bedroom?"`
