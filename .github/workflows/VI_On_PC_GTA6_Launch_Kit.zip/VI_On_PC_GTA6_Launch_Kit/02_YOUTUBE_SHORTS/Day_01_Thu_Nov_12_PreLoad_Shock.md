# Day 1 (Thu, Nov 12) — Pre-Load Shock & Curiosity Warm-Up — YouTube Shorts Pack (`@vi.onpc`)
**Daily Goal:** Trigger massive curiosity & comment arguments while warming up the algorithm AND funneling early profile clickers to your bio link.
**Upload Settings:** Select `No, it's not made for kids` | Video Language: `English (United States)`

## Short #1: The 2028 Laptop Flex (Slot 1 — 18:00 Morocco (12:00 PM EST))
- **What to Film (8–12s on iPhone 60FPS):** Start zoomed in tight on your laptop screen showing the official GTA VI PS5 Pre-Load icon & live countdown timer. At 0:04, pan down to show your glowing laptop keyboard and PS5 DualSense wired via USB-C.
- **Top On-Screen Headline:** `When everyone says laptop players have to wait until 2028 💀💻`
- **Bottom Small Text:** `(Own PS5 + official game required • 60FPS setup in bio)`
- **YouTube Short Title:**
  ```text
  They said wait until 2028 to play GTA 6 on a laptop 💀💻 #gta6 #gtavi #gamingsetup #ps5
  ```
- **YouTube Description:**
  ```text
Getting the laptop desk setup dialed in at 1080p 60FPS for GTA 6 launch week.

Exact zero-lag laptop method + launch week PSN perks linked on my channel @vi.onpc!

(Note: Uses Sony's official console-to-PC streaming method — requires your own PS5 + official game copy).

Topics: GTA 6 laptop setup, GTA VI pre-load, play PS5 on laptop, DualSense PC setup, Vice City 60fps.
  ```
- **Pinned Comment (Paste Immediately After Uploading):**
  ```text
  Exact 60FPS laptop setup method + launch-week PSN Store perks are linked right on my channel bio @vi.onpc 👇 (Requires your own PS5 + game!)
  ```
- **Poco F7 First-Comment Trigger (Post from 2nd phone 60s after upload):**
  `"Wait how do you have the GTA 6 pre-load screen on a regular laptop?? Drop the tutorial bro"`

## Short #2: Zero-Lag USB-C Controller Proof (Slot 2 — 21:00 Morocco (3:00 PM EST))
- **What to Film (8–12s on iPhone 60FPS):** Plug the USB-C cable into your DualSense controller in close-up, then flick the thumbstick rapidly next to the laptop screen showing instant 60FPS movement with zero input delay.
- **Top On-Screen Headline:** `Testing 0ms input lag on my laptop 7 days before GTA 6 drops 🔥`
- **Bottom Small Text:** `Full 60FPS config in bio 👇`
- **YouTube Short Title:**
  ```text
  Testing 0ms input lag on my laptop before GTA 6 unlocks 🎮⚡ #gta6 #ps5 #gaminglaptop #gtavi
  ```
- **YouTube Description:**
  ```text
Why play on a slow TV across the room when you can run 60FPS at your laptop desk with a wired DualSense?

Full 60FPS laptop setup + gaming perks linked on @vi.onpc!
  ```
- **Pinned Comment (Paste Immediately After Uploading):**
  ```text
  Want zero input lag on your laptop before Nov 19? Grab the 3-step config + PSN perks on my channel bio @vi.onpc 👇
  ```
- **Poco F7 First-Comment Trigger (Post from 2nd phone 60s after upload):**
  `"Is there any delay when you plug the PS5 controller into the laptop with USB-C?"`

## Short #3: The 1-Click Bed Wake-Up (Slot 3 — 00:00 Morocco (6:00 PM EST))
- **What to Film (8–12s on iPhone 60FPS):** Sit on your bed with your laptop closed. Open the laptop, click one button to wake up your PS5 from Rest Mode, and show the console dashboard popping up on the laptop screen.
- **Top On-Screen Headline:** `My bed setup for GTA 6 launch week is officially ready 💻🛌`
- **Bottom Small Text:** `Comment SETUP for the laptop method`
- **YouTube Short Title:**
  ```text
  My bed setup for GTA 6 launch week is officially ready 💻🔥 #gta6 #gamingsetup #ps5 #gtavi
  ```
- **YouTube Description:**
  ```text
Waking up my console from bed on a regular laptop in 1080p 60FPS.

Grab the exact setup checklist + launch perks on @vi.onpc!
  ```
- **Pinned Comment (Paste Immediately After Uploading):**
  ```text
  Don't get kicked off the living room TV on Nov 19 💀 Full laptop setup guide + PSN perks in my channel bio @vi.onpc!
  ```
- **Poco F7 First-Comment Trigger (Post from 2nd phone 60s after upload):**
  `"Wait you don't even have to turn the TV on for this to work??"`

## Short #4: No $3,000 PC Needed Flex (Slot 4 — 03:00 Morocco (9:00 PM EST - Auto-Scheduled))
- **What to Film (8–12s on iPhone 60FPS):** Slow aesthetic pan across your clean laptop desk in the dark with pink/blue Vice City wallpaper and your DualSense controller resting on the keyboard.
- **Top On-Screen Headline:** `You don't need a $3,000 gaming PC to play on your laptop next week 💡`
- **Bottom Small Text:** `Own PS5 + game required • Method in bio`
- **YouTube Short Title:**
  ```text
  No $3,000 PC needed for this GTA 6 laptop setup 💻⚡ #gta6 #gtavi #desksetup #ps5
  ```
- **YouTube Description:**
  ```text
How to use your PS5 to run GTA 6 on a regular laptop at 60FPS without melting your CPU.

Full setup + gaming perks linked on @vi.onpc!
  ```
- **Pinned Comment (Paste Immediately After Uploading):**
  ```text
  Exact 3-step laptop setup + optional PSN Store & gear perks linked in my channel bio @vi.onpc 👇
  ```
- **Poco F7 First-Comment Trigger (Post from 2nd phone 60s after upload):**
  `"My laptop only has 8GB RAM, will this still run at 60fps?"`
