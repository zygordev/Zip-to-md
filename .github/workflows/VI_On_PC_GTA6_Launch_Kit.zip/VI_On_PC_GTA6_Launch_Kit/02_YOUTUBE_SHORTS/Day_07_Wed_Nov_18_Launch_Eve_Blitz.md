# Day 7 (Wed, Nov 18) — Launch Eve (< 24 Hours Left) Hype Blitz — YouTube Shorts Pack (`@vi.onpc`)
**Daily Goal:** Maximum search volume day. Millions of people search GTA 6 every hour today. Push both your 60FPS setup AND your spoiler-delayed live stream.
**Upload Settings:** Select `No, it's not made for kids` | Video Language: `English (United States)`

## Short #1: 24 Hours Left Countdown Flex (Slot 1 — 18:00 Morocco (12:00 PM EST))
- **What to Film (8–12s on iPhone 60FPS):** Close-up of the final `< 24 Hours` timer ticking down on your laptop screen with your DualSense in hand.
- **Top On-Screen Headline:** `LESS THAN 24 HOURS. Playing GTA 6 on this laptop all weekend 💻🔥`
- **Bottom Small Text:** `Own PS5 + game required • Setup + stream in bio`
- **YouTube Short Title:**
  ```text
  LESS THAN 24 HOURS UNTIL GTA 6 💻🔥 #gta6 #gtavi #ps5 #gamingsetup
  ```
- **YouTube Description:**
  ```text
The 10+ year wait ends tonight. Streaming my PS5 copy of GTA 6 to my laptop at 1080p 60FPS.

Full setup + live stream + PSN perks on @vi.onpc!
  ```
- **Pinned Comment (Paste Immediately After Uploading):**
  ```text
  Set up your laptop before midnight + grab launch night PSN perks in my channel bio @vi.onpc 👇
  ```
- **Poco F7 First-Comment Trigger (Post from 2nd phone 60s after upload):**
  `"SETUP"`

## Short #2: OBS 120-Second Anti-Spoiler Delay Setup (Slot 2 — 21:00 Morocco (3:00 PM EST))
- **What to Film (8–12s on iPhone 60FPS):** Show OBS Studio -> Settings -> Advanced -> Stream Delay enabled at `120s` next to your laptop capture window.
- **Top On-Screen Headline:** `Streaming GTA 6 from my laptop tonight with a 2-minute anti-spoiler delay 🛡️🎥`
- **Bottom Small Text:** `Stream link + laptop setup in bio 👇`
- **YouTube Short Title:**
  ```text
  How I'm streaming GTA 6 tonight with ZERO chat spoilers 🛡️💻 #gta6 #gtavi #streamer #obs
  ```
- **YouTube Description:**
  ```text
Turned on a 120-second OBS Stream Delay so chat stays 100% spoiler-free while I play on my laptop.

Stream link + setup guide on @vi.onpc!
  ```
- **Pinned Comment (Paste Immediately After Uploading):**
  ```text
  Watch the spoiler-free stream + grab the 60FPS laptop setup & PSN perks in my channel bio @vi.onpc 👇
  ```
- **Poco F7 First-Comment Trigger (Post from 2nd phone 60s after upload):**
  `"W streamer for adding a spoiler delay"`

## Short #3: Final 6 Hours Desk Lock-In (Slot 3 — 00:00 Morocco (6:00 PM EST))
- **What to Film (8–12s on iPhone 60FPS):** Fast montage plugging in Ethernet, plugging in USB-C DualSense, putting on headset, and opening the countdown screen on the laptop.
- **Top On-Screen Headline:** `Final 6 hours. Locking in the 60FPS laptop station for midnight 🔓💻`
- **Bottom Small Text:** `Full setup + launch perks in bio`
- **YouTube Short Title:**
  ```text
  Locking in the laptop desk setup for GTA 6 midnight launch 🔓💻 #gta6 #gtavi #ps5 #gamingsetup
  ```
- **YouTube Description:**
  ```text
Final countdown before Vice City unlocks. Grab the 60FPS laptop setup + launch perks on @vi.onpc!
  ```
- **Pinned Comment (Paste Immediately After Uploading):**
  ```text
  Everything you need for midnight launch (60FPS laptop setup + PSN perks + stream) is in my bio @vi.onpc 👇
  ```
- **Poco F7 First-Comment Trigger (Post from 2nd phone 60s after upload):**
  `"See y'all on the other side 🫡 SETUP"`

## Short #4: 3 Hours to Midnight Launch Callout (Slot 4 — 03:00 Morocco (9:00 PM EST))
- **What to Film (8–12s on iPhone 60FPS):** Tight shot of the final countdown hours ticking down on the laptop display while tapping the DualSense triggers.
- **Top On-Screen Headline:** `We made it. Playing GTA 6 on the laptop in T-minus 3 hours 🌴🔥`
- **Bottom Small Text:** `Live stream + setup method in bio 👇`
- **YouTube Short Title:**
  ```text
  We actually made it to GTA 6 launch night 🌴💻 #gta6 #gtavi #vicecity #ps5
  ```
- **YouTube Description:**
  ```text
Going live on the laptop setup! Tap the link on @vi.onpc for the stream, 60FPS laptop method, and launch perks.
  ```
- **Pinned Comment (Paste Immediately After Uploading):**
  ```text
  WE ARE LIVE / COUNTING DOWN! Tap my channel bio @vi.onpc for the stream + 60FPS laptop method + PSN perks 👇
  ```
- **Poco F7 First-Comment Trigger (Post from 2nd phone 60s after upload):**
  `"LET'S GOOOOO"`
