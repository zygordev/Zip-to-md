# Day 6 (Tue, Nov 17) — 48 Hours Left Urgency & PSN Perks Blitz — YouTube Shorts Pack (`@vi.onpc`)
**Daily Goal:** Create massive FOMO 48 hours before launch. Tell viewers to set up their laptop NOW before PSN servers get hammered on launch night.
**Upload Settings:** Select `No, it's not made for kids` | Video Language: `English (United States)`

## Short #1: 48 Hours Left Server Warning (Slot 1 — 18:00 Morocco (12:00 PM EST))
- **What to Film (8–12s on iPhone 60FPS):** Zoom in on the 48-hour GTA VI countdown timer on your laptop screen, then show the PS Remote Play account login screen.
- **Top On-Screen Headline:** `⚠️ 48 HOURS LEFT: Link your PS5 to your laptop TODAY before PSN servers crash on launch night`
- **Bottom Small Text:** `Takes 2 minutes • Step-by-step in bio 👇`
- **YouTube Short Title:**
  ```text
  Do THIS 48 hours before GTA 6 launches on PS5 ⚠️💻 #gta6 #gtavi #ps5 #gamingsetup
  ```
- **YouTube Description:**
  ```text
Don't wait until midnight on Nov 19 when PlayStation servers are overloaded to pair your laptop with your PS5. Link it today!

Full 3-step setup on @vi.onpc!
  ```
- **Pinned Comment (Paste Immediately After Uploading):**
  ```text
  Link your PS5 to your laptop tonight in 2 minutes! Full setup + PSN perks in my channel bio @vi.onpc 👇
  ```
- **Poco F7 First-Comment Trigger (Post from 2nd phone 60s after upload):**
  `"Actually smart af, PSN login always lags on huge launch nights. SETUP"`

## Short #2: Quick Screen Tour of Your Link Hub & Perks (Slot 2 — 21:00 Morocco (3:00 PM EST))
- **What to Film (8–12s on iPhone 60FPS):** Hold your Poco F7 or iPhone in front of your laptop desk showing your landing page (`gta6_remote_play_hub.html`) scrolling through the 3 setup tabs and the PSN/Gear perks.
- **Top On-Screen Headline:** `Put my entire 60FPS GTA 6 laptop setup + launch week PSN perks on one page for y'all 💻🎁`
- **Bottom Small Text:** `Tap the link in my bio or comment SETUP 👇`
- **YouTube Short Title:**
  ```text
  My complete 60FPS GTA 6 laptop setup hub is live 💻🔥 #gta6 #ps5 #gamingsetup #gtavi
  ```
- **YouTube Description:**
  ```text
Whether you're playing wired at a PC desk, wireless on a laptop in bed, or streaming via OBS, everything is on my hub.

Link on @vi.onpc!
  ```
- **Pinned Comment (Paste Immediately After Uploading):**
  ```text
  Tap the link on my channel @vi.onpc for the free 3-step setup + optional PSN Store & gear perks 👇
  ```
- **Poco F7 First-Comment Trigger (Post from 2nd phone 60s after upload):**
  `"SETUP"`

## Short #3: The 4-Point Launch Readiness Checklist (Slot 3 — 00:00 Morocco (6:00 PM EST))
- **What to Film (8–12s on iPhone 60FPS):** Point with your finger to 4 things on your desk: 1. PS5 updated, 2. GTA 6 pre-loaded, 3. Ethernet plugged in, 4. Laptop Remote Play set to 60FPS.
- **Top On-Screen Headline:** `GTA 6 Laptop Launch Checklist (48 Hours Left) ✅💻`
- **Bottom Small Text:** `Missing anything? Full checklist in bio`
- **YouTube Short Title:**
  ```text
  GTA 6 PS5-to-Laptop Launch Checklist (48 Hours Left) ✅💻 #gta6 #gtavi #ps5 #gamingsetup
  ```
- **YouTube Description:**
  ```text
1. PS5 system software updated
2. GTA VI pre-loaded
3. Rest Mode network wake enabled
4. Laptop app set to 1080p High.

Full hub on @vi.onpc!
  ```
- **Pinned Comment (Paste Immediately After Uploading):**
  ```text
  Full interactive setup checklist + launch week perks in my channel bio @vi.onpc 👇
  ```
- **Poco F7 First-Comment Trigger (Post from 2nd phone 60s after upload):**
  `"4/4 ready for Vice City 🔥"`

## Short #4: Late-Night Vice City Desk Vibe (Slot 4 — 03:00 Morocco (9:00 PM EST - Auto-Scheduled))
- **What to Film (8–12s on iPhone 60FPS):** Aesthetic 8-second shot of your glowing laptop and DualSense with the GTA VI countdown clock ticking down.
- **Top On-Screen Headline:** `Last 2 nights of sleep before Vice City on the laptop 🌴💻`
- **Bottom Small Text:** `60FPS setup + PSN perks in bio`
- **YouTube Short Title:**
  ```text
  Last 2 nights of sleep before GTA 6 🌴💻 #gta6 #gtavi #vicecity #gamingsetup
  ```
- **YouTube Description:**
  ```text
See you in Leonida in 48 hours. Grab the laptop setup guide on @vi.onpc!
  ```
- **Pinned Comment (Paste Immediately After Uploading):**
  ```text
  Get your laptop ready before Thursday: full guide + perks in my bio @vi.onpc 👇
  ```
- **Poco F7 First-Comment Trigger (Post from 2nd phone 60s after upload):**
  `"Taking Thursday and Friday off work for this 💀"`
