# Day 4 (Sun, Nov 15) — High-Traffic Sunday Relatable Hooks — YouTube Shorts Pack (`@vi.onpc`)
**Daily Goal:** Sunday has the highest screen time of the week in the US/UK. Hit relatable angles ('Living Room TV Taken' + 'No Capture Card OBS Streaming').
**Upload Settings:** Select `No, it's not made for kids` | Video Language: `English (United States)`

## Short #1: Living Room TV Taken POV (Slot 1 — 18:00 Morocco (12:00 PM EST))
- **What to Film (8–12s on iPhone 60FPS):** Walk past the living room TV into your bedroom, open your laptop on the desk/bed, and pick up your DualSense with the PS5 screen already running.
- **Top On-Screen Headline:** `When your family thinks they're using the TV during GTA 6 launch week 💀`
- **Bottom Small Text:** `Good thing my PS5 streams straight to my laptop in 60FPS`
- **YouTube Short Title:**
  ```text
  When your family takes the living room TV on GTA 6 launch week 💀💻 #gta6 #ps5 #gaming #gtavi
  ```
- **YouTube Description:**
  ```text
Never fight over the living room TV again. Play your PS5 copy of GTA 6 straight on your laptop in 1080p 60FPS.

Setup guide + perks on @vi.onpc!
  ```
- **Pinned Comment (Paste Immediately After Uploading):**
  ```text
  Set this up on your laptop before Thursday! Full 3-step guide + PSN perks in my channel bio @vi.onpc 👇
  ```
- **Poco F7 First-Comment Trigger (Post from 2nd phone 60s after upload):**
  `"Bro this literally saved my marriage for next week 💀 SETUP"`

## Short #2: Thumbstick Flick Latency Proof (Slot 2 — 21:00 Morocco (3:00 PM EST))
- **What to Film (8–12s on iPhone 60FPS):** Hold your DualSense right up against the bottom bezel of your laptop monitor and flick the camera left/right rapidly so viewers see 1:1 instant response.
- **Top On-Screen Headline:** `'bUt tHeRe iS a 2 sEcOnD dElAy' — look at my thumbstick vs the screen 🤡`
- **Bottom Small Text:** `0ms wired setup is in my bio 👇`
- **YouTube Short Title:**
  ```text
  Replying to haters who say playing on a laptop has input lag 🤡🎮 #gta6 #ps5 #gaminglaptop #gtavi
  ```
- **YouTube Description:**
  ```text
When your PS5 is on Ethernet and your DualSense is wired via USB-C, input response is instant.

Grab my exact config on @vi.onpc!
  ```
- **Pinned Comment (Paste Immediately After Uploading):**
  ```text
  Copy my exact zero-lag settings + grab launch week PSN perks in my channel bio @vi.onpc 👇
  ```
- **Poco F7 First-Comment Trigger (Post from 2nd phone 60s after upload):**
  `"Okay wait that actually looks instant, how do you wire it?"`

## Short #3: Stream GTA 6 on OBS Without a Capture Card (Slot 3 — 00:00 Morocco (6:00 PM EST))
- **What to Film (8–12s on iPhone 60FPS):** Show OBS Studio open on your laptop capturing the PS Remote Play window at 60FPS with your mic audio bar moving.
- **Top On-Screen Headline:** `How to stream GTA 6 from PS5 to Twitch/TikTok WITHOUT a $200 capture card 🎥💻`
- **Bottom Small Text:** `Full OBS + laptop method in bio`
- **YouTube Short Title:**
  ```text
  Stream GTA 6 from PS5 on a laptop WITHOUT a capture card 🎥💻 #gta6 #obsstudio #ps5 #gtavi
  ```
- **YouTube Description:**
  ```text
Don't waste $200 on an Elgato capture card. Capture your PS5 window directly inside OBS Studio on your laptop at 60FPS.

Full guide on @vi.onpc!
  ```
- **Pinned Comment (Paste Immediately After Uploading):**
  ```text
  Want to stream or clip GTA 6 on your laptop this Thursday? Full OBS + Remote Play guide in my bio @vi.onpc 👇
  ```
- **Poco F7 First-Comment Trigger (Post from 2nd phone 60s after upload):**
  `"Wait so OBS just captures the laptop window directly at 60fps?? SETUP"`

## Short #4: 3D Audio + DualSense Haptics on PC (Slot 4 — 03:00 Morocco (9:00 PM EST - Auto-Scheduled))
- **What to Film (8–12s on iPhone 60FPS):** Plug your gaming headset into the bottom of the DualSense controller while the DualSense is connected to the laptop via USB-C.
- **Top On-Screen Headline:** `PSA: Plug your DualSense into your laptop with USB-C for full vibration & 3D audio 🎧🔥`
- **Bottom Small Text:** `Bluetooth cuts haptics • Full setup in bio`
- **YouTube Short Title:**
  ```text
  Why you MUST use a USB-C cable for your PS5 controller on laptop 🎧🎮 #gta6 #ps5 #dualsense #gtavi
  ```
- **YouTube Description:**
  ```text
Bluetooth disables full DualSense haptics on PC. Use a braided USB-C cable for full feedback and audio passthrough.

Setup + gear perks on @vi.onpc!
  ```
- **Pinned Comment (Paste Immediately After Uploading):**
  ```text
  Full controller setup + optional headset/PSN perks linked in my channel bio @vi.onpc 👇
  ```
- **Poco F7 First-Comment Trigger (Post from 2nd phone 60s after upload):**
  `"Didn't know the headphone jack on the controller works through the laptop too!"`
