# Day 5 (Mon, Nov 16) — Clone Your Top 2 Viral Winners (3 Days to Launch) — YouTube Shorts Pack (`@vi.onpc`)
**Daily Goal:** Look at your analytics from Thu–Sun. Take your #1 and #2 highest-viewed clips and re-film them with even tighter 8-second pacing and stronger CTAs.
**Upload Settings:** Select `No, it's not made for kids` | Video Language: `English (United States)`

## Short #1: Part 2 of Your #1 Most-Viewed Clip (3 Days Left Edition) (Slot 1 — 18:00 Morocco (12:00 PM EST))
- **What to Film (8–12s on iPhone 60FPS):** Re-shoot the exact visual angle of your best-performing video so far, starting with the 3-day countdown on the laptop screen.
- **Top On-Screen Headline:** `3 DAYS LEFT: Still the smartest way to play GTA 6 on a laptop at 60FPS 💻🔥`
- **Bottom Small Text:** `Requires your own PS5 + game • Setup in bio`
- **YouTube Short Title:**
  ```text
  3 DAYS LEFT until GTA 6 on the laptop desk setup 💻🔥 #gta6 #gtavi #ps5 #gamingsetup
  ```
- **YouTube Description:**
  ```text
3 days until November 19. Get your laptop and PS5 linked up tonight in under 3 minutes.

Full setup + launch perks on @vi.onpc!
  ```
- **Pinned Comment (Paste Immediately After Uploading):**
  ```text
  Don't wait until launch night! Grab the 3-step 60FPS laptop setup + PSN perks in my channel bio @vi.onpc 👇
  ```
- **Poco F7 First-Comment Trigger (Post from 2nd phone 60s after upload):**
  `"SETUP"`

## Short #2: The 'Stop Buying Fake PC Keys' Warning (Massive Trust Builder) (Slot 2 — 21:00 Morocco (3:00 PM EST))
- **What to Film (8–12s on iPhone 60FPS):** Shake your head at the camera/laptop, then point to your PS5 and the official Sony Remote Play app on your laptop screen.
- **Top On-Screen Headline:** `PSA: Stop falling for fake 'GTA 6 PC download' links 💀 There is NO PC version!`
- **Bottom Small Text:** `The ONLY legit way on laptop is streaming your own PS5 👇`
- **YouTube Short Title:**
  ```text
  STOP falling for fake GTA 6 PC download links 💀💻 #gta6 #gtavi #ps5 #pcgaming
  ```
- **YouTube Description:**
  ```text
There is NO native PC version of GTA 6 yet. The only 100% legit way to play on your laptop screen is streaming your own PS5 via Sony's official app.

Safe setup guide + perks on @vi.onpc!
  ```
- **Pinned Comment (Paste Immediately After Uploading):**
  ```text
  Stay safe! Here is the 100% official Sony PS5-to-laptop method + verified gaming perks in my bio @vi.onpc 👇
  ```
- **Poco F7 First-Comment Trigger (Post from 2nd phone 60s after upload):**
  `"Realest account on here, everyone else is posting fake PC emulators"`

## Short #3: Part 2 of Your #2 Most-Viewed Clip (Slot 3 — 00:00 Morocco (6:00 PM EST))
- **What to Film (8–12s on iPhone 60FPS):** Re-film your 2nd highest-performing video with a fresh song and faster 2-second cuts between your PS5, router, and laptop.
- **Top On-Screen Headline:** `How I got my PS5-to-laptop connection from 30fps blurry -> 1080p 60FPS crisp ⚡`
- **Bottom Small Text:** `Copy my exact settings in bio 👇`
- **YouTube Short Title:**
  ```text
  Fix blurry PS5-to-laptop graphics in 10 seconds ⚡💻 #gta6 #ps5 #gaminglaptop #gtavi
  ```
- **YouTube Description:**
  ```text
How to lock in crisp 1080p 60FPS on your laptop before GTA 6 launches on Thursday.

Full settings on @vi.onpc!
  ```
- **Pinned Comment (Paste Immediately After Uploading):**
  ```text
  Exact 1080p 60FPS settings + launch week PSN perks linked in my channel bio @vi.onpc 👇
  ```
- **Poco F7 First-Comment Trigger (Post from 2nd phone 60s after upload):**
  `"SETUP"`

## Short #4: Late-Night Comment Q&A Video Reply (Slot 4 — 03:00 Morocco (9:00 PM EST - Auto-Scheduled))
- **What to Film (8–12s on iPhone 60FPS):** Pick a new question in your comments and film a 9-second visual answer pointing to your bio link.
- **Top On-Screen Headline:** `Answering your top question before GTA 6 launch night 👇💻`
- **Bottom Small Text:** `Full setup hub in bio`
- **YouTube Short Title:**
  ```text
  Can you play GTA 6 on a MacBook with a PS5 controller? 💻🎮 #gta6 #macbook #ps5 #gtavi
  ```
- **YouTube Description:**
  ```text
Yes, Sony's official app works on both Windows 10/11 laptops and MacBooks when paired with your PS5.

Full guide on @vi.onpc!
  ```
- **Pinned Comment (Paste Immediately After Uploading):**
  ```text
  Windows & Mac setup steps + launch week PSN perks are in my channel bio @vi.onpc 👇
  ```
- **Poco F7 First-Comment Trigger (Post from 2nd phone 60s after upload):**
  `"Wait it works on MacBook Air too?! Clutch"`
