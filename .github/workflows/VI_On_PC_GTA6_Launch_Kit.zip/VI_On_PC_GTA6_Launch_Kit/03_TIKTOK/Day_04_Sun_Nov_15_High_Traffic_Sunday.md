# Day 4 (Sun, Nov 15) — High-Traffic Sunday Relatable Hooks — TikTok Pack (`@vi.onpc`)
**Daily Goal:** Sunday has the highest screen time of the week in the US/UK. Hit relatable angles ('Living Room TV Taken' + 'No Capture Card OBS Streaming').
**TikTok Tip:** Add a trending US gaming/phonk sound at `5%–8%` volume under your original clip audio so TikTok pushes it to US feeds.

## TikTok #1: Living Room TV Taken POV (Slot 1 — 18:00 Morocco (12:00 PM EST))
- **What to Film (8–12s on iPhone 60FPS):** Walk past the living room TV into your bedroom, open your laptop on the desk/bed, and pick up your DualSense with the PS5 screen already running.
- **Native TikTok Text Hook (Top Center):** `When your family thinks they're using the TV during GTA 6 launch week 💀`
- **Bottom Small Disclaimer Text:** `Good thing my PS5 streams straight to my laptop in 60FPS`
- **TikTok Caption + Hashtags (Copy-Paste):**
  ```text
  they can keep the living room TV 💀 full 60fps laptop method in bio 👇 #gta6 #gtavi #ps5 #relatable
  ```
- **Poco F7 First-Comment Trigger (Post from 2nd phone & reply to it):**
  `"Bro this literally saved my marriage for next week 💀 SETUP"`

## TikTok #2: Thumbstick Flick Latency Proof (Slot 2 — 21:00 Morocco (3:00 PM EST))
- **What to Film (8–12s on iPhone 60FPS):** Hold your DualSense right up against the bottom bezel of your laptop monitor and flick the camera left/right rapidly so viewers see 1:1 instant response.
- **Native TikTok Text Hook (Top Center):** `'bUt tHeRe iS a 2 sEcOnD dElAy' — look at my thumbstick vs the screen 🤡`
- **Bottom Small Disclaimer Text:** `0ms wired setup is in my bio 👇`
- **TikTok Caption + Hashtags (Copy-Paste):**
  ```text
  where is the lag at?? 🤡 exact 0ms config + perks in bio 👇 #gta6 #gtavi #ps5controller #gaminglaptop
  ```
- **Poco F7 First-Comment Trigger (Post from 2nd phone & reply to it):**
  `"Okay wait that actually looks instant, how do you wire it?"`

## TikTok #3: Stream GTA 6 on OBS Without a Capture Card (Slot 3 — 00:00 Morocco (6:00 PM EST))
- **What to Film (8–12s on iPhone 60FPS):** Show OBS Studio open on your laptop capturing the PS Remote Play window at 60FPS with your mic audio bar moving.
- **Native TikTok Text Hook (Top Center):** `How to stream GTA 6 from PS5 to Twitch/TikTok WITHOUT a $200 capture card 🎥💻`
- **Bottom Small Disclaimer Text:** `Full OBS + laptop method in bio`
- **TikTok Caption + Hashtags (Copy-Paste):**
  ```text
  save your $200, no capture card needed 🎥 full OBS + laptop setup in bio 👇 #gta6 #gtavi #streamer #obs
  ```
- **Poco F7 First-Comment Trigger (Post from 2nd phone & reply to it):**
  `"Wait so OBS just captures the laptop window directly at 60fps?? SETUP"`

## TikTok #4: 3D Audio + DualSense Haptics on PC (Slot 4 — 03:00 Morocco (9:00 PM EST - Auto-Scheduled))
- **What to Film (8–12s on iPhone 60FPS):** Plug your gaming headset into the bottom of the DualSense controller while the DualSense is connected to the laptop via USB-C.
- **Native TikTok Text Hook (Top Center):** `PSA: Plug your DualSense into your laptop with USB-C for full vibration & 3D audio 🎧🔥`
- **Bottom Small Disclaimer Text:** `Bluetooth cuts haptics • Full setup in bio`
- **TikTok Caption + Hashtags (Copy-Paste):**
  ```text
  never use Bluetooth when USB-C gives you full haptics 🎧 setup + perks in bio 👇 #gta6 #gtavi #dualsense #ps5
  ```
- **Poco F7 First-Comment Trigger (Post from 2nd phone & reply to it):**
  `"Didn't know the headphone jack on the controller works through the laptop too!"`
