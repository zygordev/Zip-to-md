# Day 6 (Tue, Nov 17) — 48 Hours Left Urgency & PSN Perks Blitz — TikTok Pack (`@vi.onpc`)
**Daily Goal:** Create massive FOMO 48 hours before launch. Tell viewers to set up their laptop NOW before PSN servers get hammered on launch night.
**TikTok Tip:** Add a trending US gaming/phonk sound at `5%–8%` volume under your original clip audio so TikTok pushes it to US feeds.

## TikTok #1: 48 Hours Left Server Warning (Slot 1 — 18:00 Morocco (12:00 PM EST))
- **What to Film (8–12s on iPhone 60FPS):** Zoom in on the 48-hour GTA VI countdown timer on your laptop screen, then show the PS Remote Play account login screen.
- **Native TikTok Text Hook (Top Center):** `⚠️ 48 HOURS LEFT: Link your PS5 to your laptop TODAY before PSN servers crash on launch night`
- **Bottom Small Disclaimer Text:** `Takes 2 minutes • Step-by-step in bio 👇`
- **TikTok Caption + Hashtags (Copy-Paste):**
  ```text
  don't wait until servers get slammed on Thursday ⚠️ link your laptop today (guide in bio) 👇 #gta6 #gtavi #ps5 #psa
  ```
- **Poco F7 First-Comment Trigger (Post from 2nd phone & reply to it):**
  `"Actually smart af, PSN login always lags on huge launch nights. SETUP"`

## TikTok #2: Quick Screen Tour of Your Link Hub & Perks (Slot 2 — 21:00 Morocco (3:00 PM EST))
- **What to Film (8–12s on iPhone 60FPS):** Hold your Poco F7 or iPhone in front of your laptop desk showing your landing page (`gta6_remote_play_hub.html`) scrolling through the 3 setup tabs and the PSN/Gear perks.
- **Native TikTok Text Hook (Top Center):** `Put my entire 60FPS GTA 6 laptop setup + launch week PSN perks on one page for y'all 💻🎁`
- **Bottom Small Disclaimer Text:** `Tap the link in my bio or comment SETUP 👇`
- **TikTok Caption + Hashtags (Copy-Paste):**
  ```text
  everything you need for Thursday is in my bio link 💻🎁 #gta6 #gtavi #ps5setup #gaming
  ```
- **Poco F7 First-Comment Trigger (Post from 2nd phone & reply to it):**
  `"SETUP"`

## TikTok #3: The 4-Point Launch Readiness Checklist (Slot 3 — 00:00 Morocco (6:00 PM EST))
- **What to Film (8–12s on iPhone 60FPS):** Point with your finger to 4 things on your desk: 1. PS5 updated, 2. GTA 6 pre-loaded, 3. Ethernet plugged in, 4. Laptop Remote Play set to 60FPS.
- **Native TikTok Text Hook (Top Center):** `GTA 6 Laptop Launch Checklist (48 Hours Left) ✅💻`
- **Bottom Small Disclaimer Text:** `Missing anything? Full checklist in bio`
- **TikTok Caption + Hashtags (Copy-Paste):**
  ```text
  how many do you have checked off? ✅ full setup + perks in bio 👇 #gta6 #gtavi #ps5 #checklist
  ```
- **Poco F7 First-Comment Trigger (Post from 2nd phone & reply to it):**
  `"4/4 ready for Vice City 🔥"`

## TikTok #4: Late-Night Vice City Desk Vibe (Slot 4 — 03:00 Morocco (9:00 PM EST - Auto-Scheduled))
- **What to Film (8–12s on iPhone 60FPS):** Aesthetic 8-second shot of your glowing laptop and DualSense with the GTA VI countdown clock ticking down.
- **Native TikTok Text Hook (Top Center):** `Last 2 nights of sleep before Vice City on the laptop 🌴💻`
- **Bottom Small Disclaimer Text:** `60FPS setup + PSN perks in bio`
- **TikTok Caption + Hashtags (Copy-Paste):**
  ```text
  sleep while you still can 🌴💻 setup + perks in bio 👇 #gta6 #gtavi #vicecity #gaming
  ```
- **Poco F7 First-Comment Trigger (Post from 2nd phone & reply to it):**
  `"Taking Thursday and Friday off work for this 💀"`
