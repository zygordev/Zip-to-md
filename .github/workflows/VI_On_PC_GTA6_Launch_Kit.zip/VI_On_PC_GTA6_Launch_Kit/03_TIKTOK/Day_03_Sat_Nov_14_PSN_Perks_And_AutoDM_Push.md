# Day 3 (Sat, Nov 14) — Weekend Traffic + PSN Perks Conversion Push — TikTok Pack (`@vi.onpc`)
**Daily Goal:** Saturday US/UK gaming traffic is huge. Push viewers hard toward your bio link & ManyChat DM for the 60FPS setup + PSN Store / Gear Perks.
**TikTok Tip:** Add a trending US gaming/phonk sound at `5%–8%` volume under your original clip audio so TikTok pushes it to US feeds.

## TikTok #1: The 10-Second 3-Step Formula (Slot 1 — 18:00 Morocco (12:00 PM EST))
- **What to Film (8–12s on iPhone 60FPS):** 3 fast 3-second cuts: (1) PS5 with LAN cable plugged in, (2) Laptop screen launching Sony Remote Play, (3) DualSense wired via USB-C.
- **Native TikTok Text Hook (Top Center):** `How to play your PS5 copy of GTA 6 on your laptop in 3 steps ⚡💻`
- **Bottom Small Disclaimer Text:** `Full guide + PSN Store perks in bio 👇`
- **TikTok Caption + Hashtags (Copy-Paste):**
  ```text
  3 steps for 1080p 60fps on any laptop ⚡ full setup + PSN perks in bio 👇 #gta6 #gtavi #ps5 #gaminglaptop
  ```
- **Poco F7 First-Comment Trigger (Post from 2nd phone & reply to it):**
  `"SETUP"`

## TikTok #2: Hide the Annoying Connection Popup Trick (Slot 2 — 21:00 Morocco (3:00 PM EST))
- **What to Film (8–12s on iPhone 60FPS):** On your PS5 settings screen (mirrored on the laptop), go to Settings -> System -> Remote Play -> toggle ON 'Hide Remote Play Connection Status'.
- **Native TikTok Text Hook (Top Center):** `Turn THIS setting on before recording or streaming GTA 6 on your laptop 👀`
- **Bottom Small Disclaimer Text:** `Hides the ugly connection banner • More tips in bio`
- **TikTok Caption + Hashtags (Copy-Paste):**
  ```text
  nobody talks about this setting 👀 full 60fps setup + perks in bio 👇 #gta6 #gtavi #ps5tricks #gamingsetup
  ```
- **Poco F7 First-Comment Trigger (Post from 2nd phone & reply to it):**
  `"Bro I hated that top left notification popup, didn't know you could turn it off!"`

## TikTok #3: Launch Prep Desk + PSN Perks Callout (Slot 3 — 00:00 Morocco (6:00 PM EST))
- **What to Film (8–12s on iPhone 60FPS):** Show your laptop with the GTA 6 countdown screen, your DualSense controller, and your headset on the desk.
- **Native TikTok Text Hook (Top Center):** `Pre-loaded ✅ Laptop locked at 60FPS ✅ Ready for Nov 19 🔥`
- **Bottom Small Disclaimer Text:** `Check bio for setup guide + launch week PSN perks`
- **TikTok Caption + Hashtags (Copy-Paste):**
  ```text
  5 days left until launch night 🔥 setup checklist + PSN perks in bio 👇 #gta6 #gtavi #ps5setup #gaming
  ```
- **Poco F7 First-Comment Trigger (Post from 2nd phone & reply to it):**
  `"SETUP"`

## TikTok #4: 5GHz Wi-Fi vs Ethernet Speed Test (Slot 4 — 03:00 Morocco (9:00 PM EST - Auto-Scheduled))
- **What to Film (8–12s on iPhone 60FPS):** Show a fast internet speed test on your laptop screen, then cut straight to smooth 60FPS gameplay with your DualSense.
- **Native TikTok Text Hook (Top Center):** `How fast does your Wi-Fi need to be to play GTA 6 on a laptop? 📶💻`
- **Bottom Small Disclaimer Text:** `15 Mbps+ = Smooth 60FPS • Full test in bio`
- **TikTok Caption + Hashtags (Copy-Paste):**
  ```text
  15 Mbps on 5GHz Wi-Fi is all you need 📶 full 0-lag setup in bio 👇 #gta6 #gtavi #gaminglaptop #ps5
  ```
- **Poco F7 First-Comment Trigger (Post from 2nd phone & reply to it):**
  `"What if my router is in the living room and my laptop is in my bedroom?"`
