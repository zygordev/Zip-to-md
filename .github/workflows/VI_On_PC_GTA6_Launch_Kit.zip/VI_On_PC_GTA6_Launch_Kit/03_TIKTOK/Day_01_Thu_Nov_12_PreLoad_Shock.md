# Day 1 (Thu, Nov 12) — Pre-Load Shock & Curiosity Warm-Up — TikTok Pack (`@vi.onpc`)
**Daily Goal:** Trigger massive curiosity & comment arguments while warming up the algorithm AND funneling early profile clickers to your bio link.
**TikTok Tip:** Add a trending US gaming/phonk sound at `5%–8%` volume under your original clip audio so TikTok pushes it to US feeds.

## TikTok #1: The 2028 Laptop Flex (Slot 1 — 18:00 Morocco (12:00 PM EST))
- **What to Film (8–12s on iPhone 60FPS):** Start zoomed in tight on your laptop screen showing the official GTA VI PS5 Pre-Load icon & live countdown timer. At 0:04, pan down to show your glowing laptop keyboard and PS5 DualSense wired via USB-C.
- **Native TikTok Text Hook (Top Center):** `When everyone says laptop players have to wait until 2028 💀💻`
- **Bottom Small Disclaimer Text:** `(Own PS5 + official game required • 60FPS setup in bio)`
- **TikTok Caption + Hashtags (Copy-Paste):**
  ```text
  they really said wait till 2028 💀 exact 60fps laptop method + launch perks in bio 👇 (requires your own PS5 + game) #gta6 #gtavi #gamingsetup #gaminglaptop
  ```
- **Poco F7 First-Comment Trigger (Post from 2nd phone & reply to it):**
  `"Wait how do you have the GTA 6 pre-load screen on a regular laptop?? Drop the tutorial bro"`

## TikTok #2: Zero-Lag USB-C Controller Proof (Slot 2 — 21:00 Morocco (3:00 PM EST))
- **What to Film (8–12s on iPhone 60FPS):** Plug the USB-C cable into your DualSense controller in close-up, then flick the thumbstick rapidly next to the laptop screen showing instant 60FPS movement with zero input delay.
- **Native TikTok Text Hook (Top Center):** `Testing 0ms input lag on my laptop 7 days before GTA 6 drops 🔥`
- **Bottom Small Disclaimer Text:** `Full 60FPS config in bio 👇`
- **TikTok Caption + Hashtags (Copy-Paste):**
  ```text
  0ms input delay on a regular laptop 🔥 full 60fps setup + launch perks in bio 👇 #gta6 #gtavi #ps5controller #gamingsetup
  ```
- **Poco F7 First-Comment Trigger (Post from 2nd phone & reply to it):**
  `"Is there any delay when you plug the PS5 controller into the laptop with USB-C?"`

## TikTok #3: The 1-Click Bed Wake-Up (Slot 3 — 00:00 Morocco (6:00 PM EST))
- **What to Film (8–12s on iPhone 60FPS):** Sit on your bed with your laptop closed. Open the laptop, click one button to wake up your PS5 from Rest Mode, and show the console dashboard popping up on the laptop screen.
- **Native TikTok Text Hook (Top Center):** `My bed setup for GTA 6 launch week is officially ready 💻🛌`
- **Bottom Small Disclaimer Text:** `Comment SETUP for the laptop method`
- **TikTok Caption + Hashtags (Copy-Paste):**
  ```text
  nobody is kicking me off the TV next week 💀 full laptop setup + perks in bio 👇 #gta6 #gtavi #bedsetup #gaminglaptop
  ```
- **Poco F7 First-Comment Trigger (Post from 2nd phone & reply to it):**
  `"Wait you don't even have to turn the TV on for this to work??"`

## TikTok #4: No $3,000 PC Needed Flex (Slot 4 — 03:00 Morocco (9:00 PM EST - Auto-Scheduled))
- **What to Film (8–12s on iPhone 60FPS):** Slow aesthetic pan across your clean laptop desk in the dark with pink/blue Vice City wallpaper and your DualSense controller resting on the keyboard.
- **Native TikTok Text Hook (Top Center):** `You don't need a $3,000 gaming PC to play on your laptop next week 💡`
- **Bottom Small Disclaimer Text:** `Own PS5 + game required • Method in bio`
- **TikTok Caption + Hashtags (Copy-Paste):**
  ```text
  no $3,000 rig needed 💻 exact 60fps laptop method + PSN perks in bio 👇 #gta6 #gtavi #desksetup #gaming
  ```
- **Poco F7 First-Comment Trigger (Post from 2nd phone & reply to it):**
  `"My laptop only has 8GB RAM, will this still run at 60fps?"`
