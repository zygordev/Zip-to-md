# Day 8 (Thu, Nov 19) — OFFICIAL GTA 6 LAUNCH DAY CASHOUT — TikTok Pack (`@vi.onpc`)
**Daily Goal:** Switch your landing page to LIVE NOW mode! Show real GTA 6 Vice City gameplay running on your laptop screen with your DualSense in frame.
**TikTok Tip:** Add a trending US gaming/phonk sound at `5%–8%` volume under your original clip audio so TikTok pushes it to US feeds.

## TikTok #1: ACTUAL GTA 6 Running on My Laptop Flex (Mega Viral Clip) (Slot 1 — 18:00 Morocco (12:00 PM EST))
- **What to Film (8–12s on iPhone 60FPS):** Show actual GTA 6 gameplay in Vice City running smoothly at 60FPS on your laptop screen, then pan out to show your DualSense controller and laptop keyboard.
- **Native TikTok Text Hook (Top Center):** `Playing my PS5 copy of GTA 6 on my laptop at 60FPS on Day 1 💀🌴`
- **Bottom Small Disclaimer Text:** `Exact 0-lag method + PSN perks in bio 👇`
- **TikTok Caption + Hashtags (Copy-Paste):**
  ```text
  day 1 on the laptop goes crazy 💀🌴 exact 60fps PS5-to-laptop method + perks in bio 👇 #gta6 #gtavi #vicecity #gaminglaptop
  ```
- **Poco F7 First-Comment Trigger (Post from 2nd phone & reply to it):**
  `"WAIT HOW IS IT SO SMOOTH ON A LAPTOP?! SETUP"`

## TikTok #2: Vice City Driving Latency Test on Laptop (Slot 2 — 21:00 Morocco (3:00 PM EST))
- **What to Film (8–12s on iPhone 60FPS):** Drive a fast car down Ocean Beach / Vice City neon streets on your laptop screen while keeping your hands + DualSense thumbsticks in the bottom half of the vertical frame.
- **Native TikTok Text Hook (Top Center):** `Look at the graphics & 0ms response on my laptop screen 🔥🚗`
- **Bottom Small Disclaimer Text:** `Full PS5-to-laptop setup in bio`
- **TikTok Caption + Hashtags (Copy-Paste):**
  ```text
  zero input delay in Vice City 🔥🚗 full laptop setup + perks in bio 👇 #gta6 #gtavi #vicecity #ps5
  ```
- **Poco F7 First-Comment Trigger (Post from 2nd phone & reply to it):**
  `"SETUP"`

## TikTok #3: Playing GTA 6 in Bed on Laptop POV (Slot 3 — 00:00 Morocco (6:00 PM EST))
- **What to Film (8–12s on iPhone 60FPS):** Film from bed with your laptop on your lap running GTA 6 via PS Remote Play while holding the DualSense.
- **Native TikTok Text Hook (Top Center):** `Playing GTA 6 from bed on my laptop while the TV is taken 💀🛌`
- **Bottom Small Disclaimer Text:** `Comment SETUP for the 60FPS method 👇`
- **TikTok Caption + Hashtags (Copy-Paste):**
  ```text
  peak comfort for launch week 💀🛌 full 60fps laptop setup in bio 👇 #gta6 #gtavi #bedsetup #ps5
  ```
- **Poco F7 First-Comment Trigger (Post from 2nd phone & reply to it):**
  `"Doing this tonight 100% SETUP"`

## TikTok #4: Launch Night Live Stream + Perks Recap (Slot 4 — 03:00 Morocco (9:00 PM EST - Auto-Scheduled))
- **What to Film (8–12s on iPhone 60FPS):** Show your laptop running GTA 6 + OBS Studio streaming live on your second window.
- **Native TikTok Text Hook (Top Center):** `We are LIVE playing GTA 6 on the laptop setup all night 🔴🌴`
- **Bottom Small Disclaimer Text:** `Stream link + 60FPS setup + PSN perks in bio 👇`
- **TikTok Caption + Hashtags (Copy-Paste):**
  ```text
  pull up to the launch stream 🔴🌴 link + 60fps laptop setup in bio 👇 #gta6 #gtavi #livestream #ps5
  ```
- **Poco F7 First-Comment Trigger (Post from 2nd phone & reply to it):**
  `"SETUP"`
