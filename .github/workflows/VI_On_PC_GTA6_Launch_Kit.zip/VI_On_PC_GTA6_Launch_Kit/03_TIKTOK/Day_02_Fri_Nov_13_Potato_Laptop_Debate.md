# Day 2 (Fri, Nov 13) — The 'Potato Laptop' Debate & Settings Bait — TikTok Pack (`@vi.onpc`)
**Daily Goal:** Spark massive comment debates ('How is a basic laptop running this at 60fps?!') to skyrocket watch time and drive bio clicks.
**TikTok Tip:** Add a trending US gaming/phonk sound at `5%–8%` volume under your original clip audio so TikTok pushes it to US feeds.

## TikTok #1: Task Manager 5% CPU Flex (Slot 1 — 18:00 Morocco (12:00 PM EST))
- **What to Film (8–12s on iPhone 60FPS):** Show Windows Task Manager open on the left side of your laptop screen (showing tiny CPU/GPU usage) while a fast 60FPS PS5 game runs in the window on the right.
- **Native TikTok Text Hook (Top Center):** `Running 60FPS on a regular laptop while CPU sits at 5% 💀💻`
- **Bottom Small Disclaimer Text:** `Your PS5 does 100% of the work • Setup in bio`
- **TikTok Caption + Hashtags (Copy-Paste):**
  ```text
  laptop fans aren't even spinning 💀 exact 60fps setup + PSN perks in bio 👇 #gta6 #gtavi #gaminglaptop #pcsetup
  ```
- **Poco F7 First-Comment Trigger (Post from 2nd phone & reply to it):**
  `"Bro had me thinking his office laptop had an RTX 5090 in it 😭 smart method though"`

## TikTok #2: The 2 Hidden 60FPS Settings (Slot 2 — 21:00 Morocco (3:00 PM EST))
- **What to Film (8–12s on iPhone 60FPS):** Zoom in on the Sony PS Remote Play PC settings menu: click Resolution -> 1080p, and Frame Rate -> High. Then pan to smooth gameplay.
- **Native TikTok Text Hook (Top Center):** `Stop playing on your laptop with blurry graphics. Change these 2 settings 👇`
- **Bottom Small Disclaimer Text:** `Save this before GTA 6 drops on Nov 19`
- **TikTok Caption + Hashtags (Copy-Paste):**
  ```text
  save this before Nov 19 ⚡ full 0-lag setup checklist + PSN perks in bio 👇 #gta6 #gtavi #ps5tips #gamingsetup
  ```
- **Poco F7 First-Comment Trigger (Post from 2nd phone & reply to it):**
  `"Thank you!! Mine was stuck on Standard frame rate this whole time"`

## TikTok #3: Video Reply to Top Day-1 Comment (Slot 3 — 00:00 Morocco (6:00 PM EST))
- **What to Film (8–12s on iPhone 60FPS):** Use the native Video Reply feature to reply to the top question from Day 1 while showing your PS5 Ethernet cable + laptop USB-C DualSense setup.
- **Native TikTok Text Hook (Top Center):** `Replying to @comment: Yes, any Windows 10/11 or Mac laptop works 💻✅`
- **Bottom Small Disclaimer Text:** `Requires your own PS5 + game • Link in bio`
- **TikTok Caption + Hashtags (Copy-Paste):**
  ```text
  answering the #1 question in the comments 💻 full setup + perks in bio 👇 #gta6 #gtavi #gaminglaptop #ps5
  ```
- **Poco F7 First-Comment Trigger (Post from 2nd phone & reply to it):**
  `"Just tested this on my school laptop and it actually runs smooth af"`

## TikTok #4: Dark Room Vice City Neon POV (Slot 4 — 03:00 Morocco (9:00 PM EST - Auto-Scheduled))
- **What to Film (8–12s on iPhone 60FPS):** POV filming over your shoulder in a dark room as you play at 60FPS on the laptop screen with pink/cyan lighting.
- **Native TikTok Text Hook (Top Center):** `6 days left until Vice City takes over this laptop desk 🌴💻`
- **Bottom Small Disclaimer Text:** `Setup guide + PSN perks in bio`
- **TikTok Caption + Hashtags (Copy-Paste):**
  ```text
  6 days left 🌴💻 get your laptop ready via the link in bio 👇 #gta6 #gtavi #vicecity #gamingsetup
  ```
- **Poco F7 First-Comment Trigger (Post from 2nd phone & reply to it):**
  `"This desk vibe is elite, Nov 19 cannot come fast enough"`
