# Day 7 (Wed, Nov 18) — Launch Eve (< 24 Hours Left) Hype Blitz — TikTok Pack (`@vi.onpc`)
**Daily Goal:** Maximum search volume day. Millions of people search GTA 6 every hour today. Push both your 60FPS setup AND your spoiler-delayed live stream.
**TikTok Tip:** Add a trending US gaming/phonk sound at `5%–8%` volume under your original clip audio so TikTok pushes it to US feeds.

## TikTok #1: 24 Hours Left Countdown Flex (Slot 1 — 18:00 Morocco (12:00 PM EST))
- **What to Film (8–12s on iPhone 60FPS):** Close-up of the final `< 24 Hours` timer ticking down on your laptop screen with your DualSense in hand.
- **Native TikTok Text Hook (Top Center):** `LESS THAN 24 HOURS. Playing GTA 6 on this laptop all weekend 💻🔥`
- **Bottom Small Disclaimer Text:** `Own PS5 + game required • Setup + stream in bio`
- **TikTok Caption + Hashtags (Copy-Paste):**
  ```text
  less than 24 hours left 💻🔥 last chance to set up your laptop before midnight (link in bio) 👇 #gta6 #gtavi #ps5 #launchday
  ```
- **Poco F7 First-Comment Trigger (Post from 2nd phone & reply to it):**
  `"SETUP"`

## TikTok #2: OBS 120-Second Anti-Spoiler Delay Setup (Slot 2 — 21:00 Morocco (3:00 PM EST))
- **What to Film (8–12s on iPhone 60FPS):** Show OBS Studio -> Settings -> Advanced -> Stream Delay enabled at `120s` next to your laptop capture window.
- **Native TikTok Text Hook (Top Center):** `Streaming GTA 6 from my laptop tonight with a 2-minute anti-spoiler delay 🛡️🎥`
- **Bottom Small Disclaimer Text:** `Stream link + laptop setup in bio 👇`
- **TikTok Caption + Hashtags (Copy-Paste):**
  ```text
  nobody is spoiling the story in my chat tonight 🛡️ stream link + laptop setup in bio 👇 #gta6 #gtavi #livestream #ps5
  ```
- **Poco F7 First-Comment Trigger (Post from 2nd phone & reply to it):**
  `"W streamer for adding a spoiler delay"`

## TikTok #3: Final 6 Hours Desk Lock-In (Slot 3 — 00:00 Morocco (6:00 PM EST))
- **What to Film (8–12s on iPhone 60FPS):** Fast montage plugging in Ethernet, plugging in USB-C DualSense, putting on headset, and opening the countdown screen on the laptop.
- **Native TikTok Text Hook (Top Center):** `Final 6 hours. Locking in the 60FPS laptop station for midnight 🔓💻`
- **Bottom Small Disclaimer Text:** `Full setup + launch perks in bio`
- **TikTok Caption + Hashtags (Copy-Paste):**
  ```text
  locking in for midnight 🔓💻 setup + stream + perks in bio 👇 #gta6 #gtavi #midnightlaunch #ps5
  ```
- **Poco F7 First-Comment Trigger (Post from 2nd phone & reply to it):**
  `"See y'all on the other side 🫡 SETUP"`

## TikTok #4: 3 Hours to Midnight Launch Callout (Slot 4 — 03:00 Morocco (9:00 PM EST))
- **What to Film (8–12s on iPhone 60FPS):** Tight shot of the final countdown hours ticking down on the laptop display while tapping the DualSense triggers.
- **Native TikTok Text Hook (Top Center):** `We made it. Playing GTA 6 on the laptop in T-minus 3 hours 🌴🔥`
- **Bottom Small Disclaimer Text:** `Live stream + setup method in bio 👇`
- **TikTok Caption + Hashtags (Copy-Paste):**
  ```text
  we actually made it 🌴💻 live stream + laptop setup in bio 👇 #gta6 #gtavi #vicecity #ps5
  ```
- **Poco F7 First-Comment Trigger (Post from 2nd phone & reply to it):**
  `"LET'S GOOOOO"`
